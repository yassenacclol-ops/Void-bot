// plugins/auto/void_gate.js
// 🕷️ بوابة Void - نفس نمط update_guard.js بالظبط (ده مجرب وشغال فعليًا
// في البوت أصلاً وقت وضع التحديث، فبنستخدم نفس الآلية بدل الاعتماد على
// checkType في system/control.js اللي مكنش بيتفعل صح).
import { isVoid, getMaintenance, isFrozen } from '../../system/void.js';

export default async function before(m, { conn, bot }) {
    // صاحب Void بيعدي دايمًا من أي بوابة هنا
    if (isVoid(m)) return false;

    const text = m.text || m.body || m.message?.conversation || '';
    const hasCommand = /^[./!]/.test(text.trim());
    if (!hasCommand) return false;

    // ===== وضع الصيانة =====
    const maint = getMaintenance();
    if (maint.active) {
        try { await conn.sendMessage(m.chat, { text: `🔧 ${maint.message}` }, { quoted: m }); } catch {}
        return true;
    }

    // ===== تجميد الجروب =====
    const frozen = isFrozen(m.chat);
    if (frozen) {
        const left = frozen.until
            ? `\n⏳ هيتفك تلقائي خلال ${Math.max(1, Math.ceil((frozen.until - Date.now()) / 60000))} دقيقة`
            : '';
        try {
            await conn.sendMessage(m.chat, { text: `🧊 *الجروب مجمد دلوقتي*\nالسبب: ${frozen.reason}${left}` }, { quoted: m });
        } catch {}
        return true;
    }

    return false;
}
