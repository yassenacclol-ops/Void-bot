// plugins/auto/لورد_قبل.js
// 🎯 معالج ضغطات أزرار (VOID / VENOM) اللي بتظهر بعد أمر .المطور
// بيشتغل بنفس نمط plugins/auto/صوت_ازرار.js (نمط "before")

const LORDS = {
    lord_void: {
        name: 'اللورد فويد',
        contactUrl: 'https://wa.me/201146255210',
        cardImg: 'https://raw.githubusercontent.com/moreand204-dot/photo/main/Lord_ESCANOR.png',
        audioUrl: 'https://raw.githubusercontent.com/moreand204-dot/photo/main/bot%20(2).mp3'
    },
    lord_venom: {
        name: 'اللورد فويد',
        contactUrl: 'https://wa.me/201146255210',
        cardImg: 'https://raw.githubusercontent.com/moreand204-dot/photo/main/Lord_VENOM.png',
        audioUrl: 'https://raw.githubusercontent.com/moreand204-dot/photo/main/bot2.mp3'
    }
};

export default async function before(m, { conn }) {
    if (m.fromMe) return false;

    let buttonId = null;

    if (m.message?.buttonsResponseMessage) {
        buttonId = m.message.buttonsResponseMessage.selectedButtonId;
    } else if (m.message?.templateButtonReplyMessage) {
        buttonId = m.message.templateButtonReplyMessage.selectedId;
    } else if (m.message?.interactiveResponseMessage?.nativeFlowResponseMessage) {
        buttonId = m.message.interactiveResponseMessage.nativeFlowResponseMessage.id;
    }

    const lord = LORDS[buttonId];
    if (!lord) return false;

    // 1) كرت اللورد + زرار التواصل معاه
    try {
        await conn.sendButton(m.chat, {
            imageUrl: lord.cardImg,
            bodyText: `👑 تواصل مباشر مع ${lord.name}`,
            footerText: 'Madrid Developers',
            buttons: [
                { name: 'cta_url', params: { display_text: `💬 تواصل مع ${lord.name}`, url: lord.contactUrl } }
            ],
            mentions: [m.sender],
            newsletter: { name: 'Void channel', jid: '120363000000000000@newsletter' },
            interactiveConfig: { buttons_limits: 1 }
        }, m);
    } catch (err) {
        console.error('[لورد_قبل - كرت]', err?.message);
        await conn.sendMessage(m.chat, {
            image: { url: lord.cardImg },
            caption: `👑 تواصل مباشر مع ${lord.name}\n> ${lord.contactUrl}`
        }, { quoted: m }).catch(() => {});
    }

    // 2) الصوت المرفق بعد الكرت
    try {
        await conn.sendMessage(m.chat, {
            audio: { url: lord.audioUrl },
            mimetype: 'audio/mpeg',
            ptt: false
        }, { quoted: m });
    } catch (err) {
        console.error('[لورد_قبل - صوت]', err?.message);
    }

    return true;
}
