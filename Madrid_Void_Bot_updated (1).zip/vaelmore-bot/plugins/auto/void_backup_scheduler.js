// plugins/auto/void_backup_scheduler.js
// ⏰ بيشغل تايمر مرة واحدة بس (محمي بـ global flag) بيفحص كل ساعة
// لو جاله وقت نسخة احتياطية تلقائية (حسب .جدولة_باكاب)
import { getBackupSchedule, STATE } from '../../system/void.js';
import { createVoidBackup } from '../void/backup.js';

const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;
const WEEK = 7 * DAY;

if (!global.__voidBackupTimer) {
    global.__voidBackupTimer = setInterval(async () => {
        const schedule = getBackupSchedule();
        if (schedule === 'off') return;
        const need = schedule === 'يومي' ? DAY : schedule === 'اسبوعي' ? WEEK : null;
        if (!need) return;
        const last = STATE.backup.lastRun || 0;
        if (Date.now() - last < need) return;
        try { await createVoidBackup(schedule); console.log('[void] نسخة احتياطية تلقائية اتعملت ✅'); }
        catch (e) { console.error('[void] فشلت النسخة التلقائية:', e.message); }
    }, HOUR);
}

// الملف ده بيتحمل زي أي ملف في plugins/auto عشان يشغل التايمر فوق مرة واحدة بس -
// مش بيعمل بلوك لحاجة، فبيرجع false دايمًا زي باقي ملفات before في المشروع
export default async function before(m, { conn, bot }) {
    return false;
}
