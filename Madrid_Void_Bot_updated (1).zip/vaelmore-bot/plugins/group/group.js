// كرت اختيار اللورد (بديل كرت المطور القديم)
const DEV_MENU_IMG = 'https://raw.githubusercontent.com/moreand204-dot/photo/main/Venom_and_Escanor.png';
const DEV_MENU_BODY = `╭▬▭𝅼▬࣪▭▬࣪👑▬▭▬▭▬╮\n┃ٌ╲.𝐂𝐡𝐨𝐨𝐬𝐞 𝐲𝐨𝐮𝐫 𝐋𝐨𝐫𝐝╲ٌ‌┃\n╰▬▭𝅼▬࣪▭𝅼▬👑▬ׄ▭▬࣪▭𝅼▬╯\n┃ اختار مين تحب تتواصل معاه 👇 ┃\n╰▬▭𝅼▬࣪▭𝅼▬ׄ👑▬ׄ▭▬▭▬╯`;

// رسائل البوت - ديناميكية حسب اسم المطور
const makeOwnerBotMsgs = (ownerName) => [
    `تم استشعار المطور 👁‍🗨\nالنظام تحت أمرك يا سيد ${ownerName} 👑⚡`,
    `${ownerName} هنا 🕷️\nأوامرك يا معلم 👑`,
];

const handler = async (m, { conn, bot, command }) => {
    const owners = bot?.config?.owners || [];

    // جيب بيانات المطور اللي كتب الأمر لو موجود
    const ownerEntry = owners.find(o =>
        m.sender === o.jid || m.sender === o.lid
    );
    const isOwner = !!ownerEntry;
    const ownerName = ownerEntry?.name || 'Madrid';

    if (command === 'بوت') {
        if (isOwner) {
            const msgs = makeOwnerBotMsgs(ownerName);
            return conn.sendMessage(m.chat, {
                text: msgs[Math.floor(Math.random() * msgs.length)]
            }, { quoted: m });
        }
        return conn.sendMessage(m.chat, {
            text: `أنا Madrid… نادِني باسمي يا هذا ☠️`
        }, { quoted: m });
    }

    if (command === 'المطور' || command === 'مطور') {
        if (global.devStatus === 'closed') {
            return conn.sendMessage(m.chat, {
                text: `*المطور مش فاضي دلوقتي 🛡⚜️*`
            }, { quoted: m });
        }

        try {
            return conn.sendButton(m.chat, {
                imageUrl: DEV_MENU_IMG,
                bodyText: DEV_MENU_BODY,
                footerText: 'Madrid Developers',
                buttons: [
                    { name: 'quick_reply', params: { display_text: '𝐕𝐎𝐈𝐃', id: 'lord_void' } },
                    { name: 'quick_reply', params: { display_text: '𝐕𝐄𝐍𝐎𝐌', id: 'lord_venom' } }
                ],
                mentions: [m.sender],
                newsletter: { name: 'Void channel', jid: '120363000000000000@newsletter' },
                interactiveConfig: { buttons_limits: 2, list_title: '', button_title: '' }
            }, m);
        } catch {
            return conn.sendMessage(m.chat, {
                image: { url: DEV_MENU_IMG },
                caption: DEV_MENU_BODY
            }, { quoted: m });
        }
    }
};

handler.command = ['بوت', 'المطور', 'مطور'];
handler.usePrefix = false;

export default handler;
