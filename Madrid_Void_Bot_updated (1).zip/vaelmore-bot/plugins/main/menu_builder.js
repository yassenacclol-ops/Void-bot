import fs from 'fs';
import { Button } from '../../core/NIXCODE.js';
import { getTimezone } from '../../system/timezone.js';
import { ui, frame, mainMenuText, sectionMenuText } from '../../system/ui.js';

// ⚙️ شكل كل القوائم بيتحكم فيه system/ui.js - وبتتعدل من أوامر المطور (.قوائم)
const SUPPORT_GROUP_URL = 'https://whatsapp.com/channel/0029VbENuHU8aKvSBrVn6F03';

async function safeText(conn, m, text) {
    try {
        return await conn.sendMessage(m.chat, { text, mentions: [m.sender] }, { quoted: m });
    } catch (e) {
        console.error('[menu_builder] حتى الرسالة النصية فشلت:', e?.message);
        return null;
    }
}

// صورة القايمة اللي المطور حطها (رابط أو ملف) - لو فشلت بنرجع للكارت التلقائي
async function customHeader() {
    const src = ui().headerImage;
    if (!src) return null;
    try {
        if (/^https?:\/\//i.test(src)) {
            const r = await fetch(src, { signal: AbortSignal.timeout(8000) });
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return Buffer.from(await r.arrayBuffer());
        }
        if (fs.existsSync(src)) return fs.readFileSync(src);
    } catch (e) { console.error('[menu_builder] صورة القايمة المخصصة فشلت:', e?.message); }
    return null;
}

async function sendMainMenu(m, { conn, bot }, { sections, user, totalUsers } = {}) {
  try {
    const mention = m.sender.split('@')[0];
    const list = sections || [];
    const bodyText = mainMenuText({ mention, sections: list });

    // صورة الهيدر: صورة المطور المخصصة، وإلا كارت الأوامر التلقائي
    let cardBuffer = await customHeader();
    if (!cardBuffer) {
        try {
            const { createMadridMenuCard } = await import('../../src/lib/madrid-menu-card.js');
            let tz; try { tz = getTimezone(); } catch {}
            const now = new Date();
            const f = (o) => { try { return now.toLocaleDateString('ar-EG', { ...o, timeZone: tz }); } catch { return now.toLocaleDateString('ar-EG', o); } };
            const avatarUrl = await conn.profilePictureUrl(m.sender, 'image').catch(() => null);
            cardBuffer = await createMadridMenuCard({
                avatarUrl, username: m.pushName || mention,
                day: f({ weekday: 'long' }), date: f({ year: 'numeric', month: 'long', day: 'numeric' }),
                level: user?.level ?? '-', role: user?.role ?? '-', users: totalUsers ?? '-'
            });
        } catch (e) {
            console.error('[sendMainMenu] فشل توليد صورة القايمة:', e?.message);
            cardBuffer = null;
        }
    }

    // الإرسال الأساسي: صورة + النص المؤطّر + القايمة المنسدلة بالأقسام
    try {
        const btn = new Button(conn);
        if (cardBuffer) btn.setImage(cardBuffer);
        btn.setBody(bodyText);
        btn.setFooter(ui().brand);
        if (list.length) btn.addSelection(ui().button);
        for (let i = 0; i < list.length; i += 10) {
            btn.makeSection(list.length > 10 ? `${ui().title} (${Math.floor(i / 10) + 1})` : ui().title);
            for (const s of list.slice(i, i + 10))
                btn.makeRow('', `${s.emoji} ${s.name}`, s.highlight ? `${s.count} أمر • ${s.highlight}` : `${s.count} أمر`, `.اوامر ${s.num}`);
        }
        btn.addReply('🤖 تنصيب بوت', '.تنصيب').addUrl('👥 جروب الدعم', SUPPORT_GROUP_URL);
        return await btn.send(m.chat, { quoted: m, mentions: [m.sender] });
    } catch (e) {
        console.error('[sendMainMenu] فشل إرسال الكارت التفاعلي:', e?.message);
    }

    // فولباك 1: الصورة + النص
    if (cardBuffer) {
        try { return await conn.sendMessage(m.chat, { image: cardBuffer, caption: bodyText, mentions: [m.sender] }, { quoted: m }); }
        catch (e2) { console.error('[sendMainMenu] فشل إرسال صورة القايمة:', e2?.message); }
    }
    // فولباك 2: نص بس
    return safeText(conn, m, bodyText);
  } catch (e) {
    console.error('[sendMainMenu] خطأ غير متوقع:', e?.message);
    return safeText(conn, m, '*❌ حصل خطأ في عرض القائمة، جرب تاني.*');
  }
}

async function sendSectionMenu(m, { conn, bot }, { sectionId, sectionTitle, sectionEmoji, rows, backCommand = 'اوامر' } = {}) {
  try {
    const bodyText = sectionMenuText({ mention: m.sender.split('@')[0], emoji: sectionEmoji, title: sectionTitle, rows: rows || [] });
    try {
        return await conn.sendButton(m.chat, {
            bodyText,
            footerText: ui().brand,
            buttons: [
                {
                    name: 'single_select',
                    params: {
                        title: `${sectionEmoji} الأوامر`,
                        sections: [{
                            title: `${sectionTitle}`,
                            rows: (rows || []).map(r => ({ title: `.${r.cmd}`, description: r.desc || sectionTitle, id: `.${r.cmd}` }))
                        }]
                    }
                },
                { name: 'quick_reply', params: { display_text: '🔙 الرئيسية', id: `.${backCommand}` } }
            ],
            mentions: [m.sender],
            interactiveConfig: { buttons_limits: 2 }
        }, m);
    } catch (e) {
        return safeText(conn, m, bodyText);
    }
  } catch (e) {
    return safeText(conn, m, '*❌ حصل خطأ في عرض القائمة، جرب تاني.*');
  }
}

async function sendDevMenu(m, { conn, bot }, isDev, backCommand = 'اوامر') {
    if (!isDev) return null;
    const cmds = [
        { cmd: 'قوائم', desc: 'تعديل شكل القوائم والأسماء' },
        { cmd: 'قسم', desc: 'تعديل قسم (اسم/إيموجي/إخفاء/ترتيب)' },
        { cmd: 'اعطاء_نقاط', desc: 'تدي نقاط للاعب' },
        { cmd: 'سحب_نقاط', desc: 'تسحب نقاط من لاعب' },
        { cmd: 'بنج', desc: 'اختبار سرعة البوت' },
        { cmd: 'الرام', desc: 'استخدام الذاكرة' },
        { cmd: 'الايرورات', desc: 'آخر الأخطاء' },
        { cmd: 'اضافه_مطور', desc: 'إضافة مطور جديد' },
        { cmd: 'حظر', desc: 'حظر مستخدم' },
        { cmd: 'البوتات', desc: 'إدارة البوتات الفرعية' },
        { cmd: 'تنظيف', desc: 'حذف الملفات المؤقتة' }
    ];
    const bodyText = sectionMenuText({ mention: m.sender.split('@')[0], emoji: '👨🏻‍💻', title: 'قائمة المطورين', rows: cmds });
    try {
        return await conn.sendButton(m.chat, {
            bodyText, footerText: ui().brand,
            buttons: [
                { name: 'single_select', params: { title: 'أوامر المطورين 👨🏻‍💻', sections: [{ title: 'قسم المطورين', rows: cmds.map(c => ({ title: `.${c.cmd}`, description: c.desc, id: `.${c.cmd}` })) }] } },
                { name: 'quick_reply', params: { display_text: '🔙 الرئيسية', id: `.${backCommand}` } }
            ],
            mentions: [m.sender], interactiveConfig: { buttons_limits: 2 }
        }, m);
    } catch (e) { return safeText(conn, m, bodyText); }
}

async function sendCategoriesList(m, { conn, bot }, { rows } = {}) {
    const bodyText = frame('الأقسام المتاحة', '📁', ['اختار القسم اللي عايز تشوف أوامره']);
    if (!rows || !rows.length) return safeText(conn, m, '*❌ مفيش أقسام متاحة دلوقتي*');
    try {
        return await conn.sendButton(m.chat, {
            bodyText, footerText: ui().brand,
            buttons: [{ name: 'single_select', params: { title: 'الأقسام 📁', sections: [{ title: 'كل الأقسام', rows }] } }],
            mentions: [m.sender], interactiveConfig: { buttons_limits: 1 }
        }, m);
    } catch (e) {
        return safeText(conn, m, `${bodyText}\n\n${rows.map(r => `> ${r.title} — ${r.id}`).join('\n')}`);
    }
}

async function sendLinksList(m, { conn, bot }, { rows } = {}) {
    const bodyText = frame('روابط وتواصل', '🔗', ['كل روابط وخدمات البوت هنا']);
    if (!rows || !rows.length) return safeText(conn, m, '*❌ مفيش روابط متاحة دلوقتي*');
    try {
        return await conn.sendButton(m.chat, {
            bodyText, footerText: ui().brand,
            buttons: [{ name: 'single_select', params: { title: 'الروابط 🔗', sections: [{ title: 'روابط وخدمات', rows }] } }],
            mentions: [m.sender], interactiveConfig: { buttons_limits: 1 }
        }, m);
    } catch (e) {
        return safeText(conn, m, `${bodyText}\n\n${rows.map(r => `> ${r.title} — ${r.description || ''}`).join('\n')}`);
    }
}

// نفس منطق sendSectionMenu بالظبط - اسم تاني بيستخدمه بعض البلجنز
const sendSectionList = sendSectionMenu;

export { sendMainMenu, sendSectionMenu, sendDevMenu, sendCategoriesList, sendLinksList, sendSectionList };
