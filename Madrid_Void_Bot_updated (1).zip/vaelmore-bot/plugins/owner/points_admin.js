// 👑 التحكم في النقاط (للمطور بس): .اعطاء_نقاط .سحب_نقاط .تصفير_نقاط
import { DB, fmt, uidOfJid, getPlayer, save } from '../../system/economy.js';

const toEn = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

const handler = async (m, { conn, args = [], command }) => {
    if (!m.isOwner) return m.reply('*❌ الأمر ده للمطورين بس*');
    const a = args.map(toEn);
    const nums = a.filter(x => /^\d+$/.test(x));
    const jid = m.mentionedJid?.[0] || m.quoted?.sender;
    let target = jid ? await uidOfJid(jid, conn) : nums.find(n => n.length >= 8);
    if (!target) return m.reply(`*📌 مثال:* \`.${command} @اللاعب ${command === 'تصفير_نقاط' ? '' : '5000'}\``);
    const p = getPlayer(target);
    if (jid) p.jid = jid;

    if (command === 'تصفير_نقاط') {
        p.money = 0; save();
        return m.reply(`🧹 صفّرت نقاط *${p.name || target}*`);
    }
    const amount = Number([...nums].reverse().find(n => n !== target));
    if (!Number.isSafeInteger(amount) || amount <= 0) return m.reply('*⚠️ اكتب مبلغ صح*');
    if (command === 'اعطاء_نقاط') p.money += amount;
    else p.money = Math.max(0, p.money - amount);
    save();
    return m.reply(`✅ ${command === 'اعطاء_نقاط' ? 'ضفت' : 'سحبت'} *${fmt(amount)}*\n👤 ${p.name || target}\n💰 رصيده: *${fmt(p.money)}*`);
};

handler.usage = ['اعطاء_نقاط', 'سحب_نقاط', 'تصفير_نقاط'];
handler.desc = 'التحكم في نقاط اللاعبين 💰';
handler.category = 'owner';
handler.command = ['اعطاء_نقاط', 'سحب_نقاط', 'تصفير_نقاط'];
handler.owner = true;
export default handler;
