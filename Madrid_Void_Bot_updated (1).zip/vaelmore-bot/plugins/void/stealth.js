// plugins/void/stealth.js
// 👤 .تخفي تشغيل / .تخفي ايقاف
// وقت ما يكون شغال: أي أمر من قسم Void بيتنفذ، بس الرد بيتبعت في الخاص
// (شات المطور نفسه) بدل ما يظهر في الجروب، ورسالة الأمر الأصلية بتتمسح
// لو البوت عنده صلاحية مسح - عشان محدش في الجروب يعرف إن حصل أي حاجة.
//
// ⚠️ ملحوظة صريحة: ده بيخفي أوامر قسم Void بس (اللي بتستخدم voidReply من
// system/void.js). أوامر owner العادية (زي .رستارت) لسه بترد عادي في
// الجروب زي ما هي، لأن تعديلها كلها هيبقى تغيير كبير في كل البلجنز.
import { isVoid, setStealth, getStealth } from '../../system/void.js';

const handler = async (m, { command }) => {
    if (!isVoid(m)) return;

    if (command === 'تخفي') {
        const on = getStealth();
        return m.reply(`👤 *وضع التخفي دلوقتي:* ${on ? 'شغال ✅' : 'مقفول ❌'}\n\nللتشغيل: *.تخفي تشغيل*\nللإيقاف: *.تخفي ايقاف*`);
    }

    if (command === 'تخفي_تشغيل') {
        setStealth(true);
        try { await m.delete?.(); } catch {}
        return; // مفيش رد في الجروب أصلاً - ده جوهر وضع التخفي
    }

    if (command === 'تخفي_ايقاف') {
        setStealth(false);
        return m.reply('👤 *وضع التخفي اتقفل* - أوامر Void هترد عادي دلوقتي');
    }
};

handler.usage = ['تخفي', 'تخفي_تشغيل', 'تخفي_ايقاف'];
handler.descs = { 'تخفي': 'يعرض حالة التخفي', 'تخفي_تشغيل': 'يشغل وضع التخفي', 'تخفي_ايقاف': 'يوقف وضع التخفي' };
handler.desc = 'تخفي هوية المطور في أوامر Void 👤';
handler.category = 'void';
handler.command = ['تخفي', 'تخفي_تشغيل', 'تخفي_ايقاف'];
handler.usePrefix = true;

export default handler;
