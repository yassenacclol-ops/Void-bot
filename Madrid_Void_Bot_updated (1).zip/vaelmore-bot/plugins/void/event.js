// plugins/void/event.js
// ⚡ .حدث [×2..×10] [دقايق] [عام|هنا] [اسم_لعبة]
// ⚡ .وقف_حدث
// ⚡ .حالة_الحدث
//
// أمثلة:
//  .حدث x2 30            → ×2 على كل حاجة، في كل الجروبات، لمدة 30 دقيقة
//  .حدث x5 60 هنا         → ×5 في الجروب ده بس، لمدة ساعة
//  .حدث x10 15 عام فلاج   → ×10 على لعبة العلم بس، في كل الجروبات، 15 دقيقة
//  .حدث x3 0 هنا          → ×3 في الجروب ده، من غير وقت انتهاء (لحد ما توقفه يدوي)
import { isVoid, startEvent, stopEvent, getEvent, voidReply } from '../../system/void.js';

const toEn = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const fmtLeft = (ms) => {
    if (!ms) return 'من غير وقت انتهاء';
    const mins = Math.max(0, Math.ceil(ms / 60000));
    if (mins < 60) return `${mins} دقيقة`;
    return `${Math.floor(mins / 60)} ساعة و${mins % 60} دقيقة`;
};

const handler = async (m, { conn, command, args = [] }) => {
    if (!isVoid(m)) return;

    if (command === 'وقف_حدث') {
        if (!getEvent()) return voidReply(m, conn, 'ℹ️ مفيش حدث شغال أصلاً');
        stopEvent();
        return voidReply(m, conn, '🛑 *اتوقف الحدث* - النقاط رجعت عادية');
    }

    if (command === 'حالة_الحدث') {
        const e = getEvent();
        if (!e) return voidReply(m, conn, 'ℹ️ مفيش حدث شغال دلوقتي');
        return voidReply(m, conn,
            `⚡ *حدث شغال دلوقتي*\n` +
            `✖️ المضاعفة: ×${e.multiplier}\n` +
            `🌐 النطاق: ${e.scope === 'chat' ? 'جروب واحد بس' : 'كل الجروبات'}\n` +
            `🎮 اللعبة: ${e.game || 'كل الألعاب'}\n` +
            `⏳ الوقت المتبقي: ${fmtLeft(e.expiresAt ? e.expiresAt - Date.now() : 0)}`
        );
    }

    // .حدث x2 30 هنا فلاج
    const a = args.map(toEn);
    const multRaw = (a.shift() || '').replace(/[x×*]/gi, '');
    const multiplier = parseInt(multRaw, 10);
    if (!multiplier || multiplier < 2 || multiplier > 10) {
        return voidReply(m, conn, '❌ اكتب المضاعفة من ×2 لـ ×10، مثال:\n*.حدث x2 30 هنا*');
    }
    const minutes = /^\d+$/.test(a[0] || '') ? Number(a.shift()) : 0;
    let scope = 'global';
    if (a[0] === 'هنا' || a[0] === 'جروب') { scope = 'chat'; a.shift(); }
    else if (a[0] === 'عام') { a.shift(); }
    const game = a.join(' ') || null;

    const e = startEvent({ multiplier, minutes, scope, chat: m.chat, game });

    const announce =
        `⚡⚡ *حدث مضاعفة نقاط!* ⚡⚡\n\n` +
        `✖️ كل ${e.game ? `نقاط لعبة ${e.game}` : 'النقاط'} دلوقتي ×${e.multiplier}\n` +
        `⏳ المدة: ${fmtLeft(e.expiresAt ? e.expiresAt - Date.now() : 0)}\n\n` +
        `يلا العبوا وخدوا أكتر فلوس من العادي! 💎`;

    if (scope === 'global') {
        try {
            const groups = Object.keys(await conn.groupFetchAllParticipating());
            for (const g of groups) {
                conn.sendMessage(g, { text: announce }).catch(() => {});
            }
        } catch (e2) { console.error('[void event] فشل إعلان الحدث لكل الجروبات:', e2.message); }
    } else {
        conn.sendMessage(m.chat, { text: announce }).catch(() => {});
    }

    return voidReply(m, conn, `✅ *اتفعل الحدث* (×${e.multiplier}، ${scope === 'chat' ? 'الجروب ده بس' : 'كل الجروبات'}${e.game ? `، لعبة ${e.game} بس` : ''})`);
};

handler.usage = ['حدث', 'وقف_حدث', 'حالة_الحدث'];
handler.descs = { 'حدث': 'يبدأ حدث مضاعفة نقاط', 'وقف_حدث': 'يوقف الحدث الشغال', 'حالة_الحدث': 'يعرض تفاصيل الحدث الحالي' };
handler.desc = 'حدث مضاعفة النقاط ⚡';
handler.category = 'void';
handler.command = ['حدث', 'وقف_حدث', 'حالة_الحدث'];
handler.usePrefix = true;

export default handler;
