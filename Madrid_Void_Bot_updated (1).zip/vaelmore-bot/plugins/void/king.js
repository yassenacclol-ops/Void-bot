// plugins/void/king.js
// 👑 .الملك - بطاقة ذهبية/سودا خاصة بصاحب Void، بإحصائيات حية
import { isVoid, getEvent, getCommandCount, voidReplyImage } from '../../system/void.js';
import { createVoidKingCard } from '../../src/lib/void-king-card.js';

const SIGNATURES = [
    'الملك شايف كل حاجة 👁️',
    'النظام تحت سيطرته بالكامل 🕷️',
    'مفيش حاجة بتتحرك من غير ما يعرفها',
    'Void مملكته، والباقي زوار',
    'لو حد سأل، قوله هو صاحب السيستم'
];

const dur = (ms) => {
    const s = Math.floor(ms / 1000);
    const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), mnt = Math.floor((s % 3600) / 60);
    const parts = [];
    if (d) parts.push(`${d} يوم`);
    if (h) parts.push(`${h} ساعة`);
    parts.push(`${mnt} دقيقة`);
    return parts.join(' و');
};

const handler = async (m, { conn }) => {
    if (!isVoid(m)) return;

    let groupsCount = '-';
    try { groupsCount = Object.keys(await conn.groupFetchAllParticipating()).length; } catch {}

    const uptime = dur(process.uptime() * 1000);
    const event = getEvent();
    const eventLine = event
        ? `الحدث الشغال: ×${event.multiplier} ${event.game || 'الكل'}`
        : 'الحدث الشغال: لا يوجد';

    const stats = [
        `شغال من: ${uptime}`,
        `الجروبات: ${groupsCount}`,
        `أوامر النهاردة: ${getCommandCount()}`,
        eventLine
    ];

    let avatarUrl = null;
    try { avatarUrl = await conn.profilePictureUrl(m.sender, 'image'); } catch {}

    try {
        const img = await createVoidKingCard({
            avatarUrl,
            username: m.pushName || m.sender.split('@')[0],
            stats,
            signature: SIGNATURES[Math.floor(Math.random() * SIGNATURES.length)]
        });
        return voidReplyImage(m, conn, img, '👑 *بطاقة الملك*');
    } catch (e) {
        console.error('[void king]', e.message);
        return m.reply(`👑 *الملك*\n\n${stats.join('\n')}\n\n_(فشل توليد الصورة، ده نص بديل)_`);
    }
};

handler.usage = ['الملك'];
handler.desc = 'بطاقة الملك الخاصة 👑';
handler.category = 'void';
handler.command = ['الملك'];
handler.usePrefix = true;

export default handler;
