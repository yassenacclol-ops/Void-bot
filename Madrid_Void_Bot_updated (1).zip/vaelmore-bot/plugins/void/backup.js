// plugins/void/backup.js
// 💾 .باكاب - ياخد نسخة احتياطية فورًا ويبعتها
// 💾 .جدولة_باكاب [يومي|اسبوعي|ايقاف] - يجدول نسخ تلقائية
// 💾 .قائمة_باكاب - يعرض النسخ المتاحة
// 💾 .استرجاع [اسم الملف] - يرجع نسخة معينة فوق المشروع (محتاج ريستارت يدوي بعدها)
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import archiver from 'archiver';
import AdmZip from 'adm-zip';
import { isVoid, VOID_NUMBER, setBackupSchedule, getBackupSchedule, markBackupRun, voidReply } from '../../system/void.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..', '..');
const BACKUP_DIR = path.join(ROOT, 'backups', 'void');
const IGNORE_DIRS = new Set(['node_modules', '.git', 'backups', 'session', 'auth', 'auth_info', 'temp_update']);
const MAX_KEEP = 20; // أقصى عدد نسخ محفوظة - الأقدم بتتمسح تلقائي

if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

// ===== تأمين مسار الاسترجاع (Zip Slip) =====
const safeZipPath = (entryName) => {
    if (!entryName) return null;
    const rel = entryName.replace(/\\/g, '/').replace(/^\/+/, '');
    const parts = rel.split('/').filter(p => p && p !== '.');
    if (!parts.length || parts.some(p => p === '..')) return null;
    if (IGNORE_DIRS.has(parts[0])) return null;
    const full = path.join(ROOT, ...parts);
    if (full !== ROOT && !full.startsWith(ROOT + path.sep)) return null;
    return full;
};

// ===== إنشاء نسخة احتياطية - بيتصدّر ويتستخدم من أماكن تانية (eval/exec/تحديث) =====
export async function createVoidBackup(label = 'يدوي') {
    const safeLabel = String(label).replace(/[^\p{L}\p{N}_-]+/gu, '_').slice(0, 24) || 'نسخة';
    const file = `void_${safeLabel}_${Date.now()}.zip`;
    const zipPath = path.join(BACKUP_DIR, file);

    const output = fs.createWriteStream(zipPath);
    const archive = archiver('zip', { zlib: { level: 6 } });
    const done = new Promise((resolve, reject) => { output.on('close', resolve); archive.on('error', reject); });
    archive.pipe(output);
    archive.glob('**/*', {
        cwd: ROOT,
        ignore: ['node_modules/**', '.git/**', 'backups/**', 'session/**', 'auth/**', 'auth_info/**', '*.zip', '*.log']
    });
    await archive.finalize();
    await done;

    // تنضيف: نسيب آخر MAX_KEEP بس
    try {
        const all = fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith('.zip')).map(f => ({ f, t: fs.statSync(path.join(BACKUP_DIR, f)).mtimeMs }));
        all.sort((a, b) => b.t - a.t);
        for (const old of all.slice(MAX_KEEP)) { try { fs.unlinkSync(path.join(BACKUP_DIR, old.f)); } catch {} }
    } catch {}

    markBackupRun();
    return { file, zipPath, size: fs.statSync(zipPath).size };
}

const fmtSize = (b) => b > 1024 * 1024 ? `${(b / 1024 / 1024).toFixed(1)}MB` : `${(b / 1024).toFixed(0)}KB`;

const handler = async (m, { conn, command, args = [] }) => {
    if (!isVoid(m)) return;

    if (command === 'باكاب') {
        const sent = await conn.sendMessage(m.chat, { text: '⏳ بجهز النسخة الاحتياطية...' }, { quoted: m });
        try {
            const { zipPath, file, size } = await createVoidBackup('يدوي');
            await conn.sendMessage(m.chat, { text: `✅ جاهزة (${fmtSize(size)})`, edit: sent.key }).catch(() => {});
            await conn.sendMessage(m.chat, { document: { stream: fs.createReadStream(zipPath) }, mimetype: 'application/zip', fileName: file }, { quoted: m });
        } catch (e) {
            console.error('[void backup]', e.message);
            await conn.sendMessage(m.chat, { text: '❌ حصل خطأ في تجهيز النسخة', edit: sent.key }).catch(() => {});
        }
        return;
    }

    if (command === 'جدولة_باكاب') {
        const sub = (args[0] || '').trim();
        if (!['يومي', 'اسبوعي', 'ايقاف'].includes(sub)) {
            return voidReply(m, conn, `📅 الجدولة الحالية: *${getBackupSchedule()}*\n\nاختار: *.جدولة_باكاب يومي* أو *اسبوعي* أو *ايقاف*`);
        }
        setBackupSchedule(sub === 'ايقاف' ? 'off' : sub);
        return voidReply(m, conn, `✅ الجدولة بقت: *${sub}*`);
    }

    if (command === 'قائمة_باكاب') {
        const all = fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith('.zip'))
            .map(f => ({ f, t: fs.statSync(path.join(BACKUP_DIR, f)).mtimeMs, s: fs.statSync(path.join(BACKUP_DIR, f)).size }))
            .sort((a, b) => b.t - a.t);
        if (!all.length) return voidReply(m, conn, 'ℹ️ مفيش نسخ احتياطية لسه');
        const lines = all.slice(0, 15).map(x => `• ${x.f} — ${fmtSize(x.s)} — ${new Date(x.t).toLocaleString('ar-EG')}`);
        return voidReply(m, conn, `💾 *آخر النسخ الاحتياطية:*\n\n${lines.join('\n')}\n\nللاسترجاع: *.استرجاع [اسم الملف]*`);
    }

    if (command === 'استرجاع') {
        const name = (args[0] || '').trim();
        if (!name) return voidReply(m, conn, '❌ اكتب اسم الملف، شوفه بـ *.قائمة_باكاب*');
        const zipPath = path.join(BACKUP_DIR, name);
        if (!zipPath.startsWith(BACKUP_DIR + path.sep) || !fs.existsSync(zipPath)) {
            return voidReply(m, conn, '❌ مش لاقي النسخة دي');
        }
        try {
            const zip = new AdmZip(zipPath);
            let count = 0;
            for (const e of zip.getEntries()) {
                if (e.isDirectory) continue;
                const dest = safeZipPath(e.entryName);
                if (!dest) continue;
                fs.mkdirSync(path.dirname(dest), { recursive: true });
                fs.writeFileSync(dest, e.getData());
                count++;
            }
            return voidReply(m, conn, `✅ *تم الاسترجاع* (${count} ملف)\n⚠️ محتاج تعمل *.رستارت* دلوقتي عشان التغييرات تتفعل بالكامل`);
        } catch (e) {
            console.error('[void restore]', e.message);
            return voidReply(m, conn, '❌ حصل خطأ في الاسترجاع، الملف ممكن يكون تالف');
        }
    }
};

handler.usage = ['باكاب', 'جدولة_باكاب', 'قائمة_باكاب', 'استرجاع'];
handler.descs = {
    'باكاب': 'ياخد نسخة احتياطية فورية',
    'جدولة_باكاب': 'يجدول نسخ تلقائية (يومي/اسبوعي)',
    'قائمة_باكاب': 'يعرض النسخ المتاحة',
    'استرجاع': 'يرجع نسخة معينة فوق المشروع'
};
handler.desc = 'النسخ الاحتياطية 💾';
handler.category = 'void';
handler.command = ['باكاب', 'جدولة_باكاب', 'قائمة_باكاب', 'استرجاع'];
handler.usePrefix = true;

export default handler;
