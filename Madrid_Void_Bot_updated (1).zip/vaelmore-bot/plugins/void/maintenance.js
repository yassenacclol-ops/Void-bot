// plugins/void/maintenance.js
// 🔧 .صيانة تشغيل [رسالة] - يقفل البوت عن أي حد غيرك في كل الجروبات
// 🔧 .صيانة ايقاف - يرجع البوت يشتغل عادي
// الفحص والمنع الفعلي بيحصل في system/control.js (access) عشان يتطبق
// قبل أي أمر من أي مكان، مش بس من هنا.
import { isVoid, setMaintenance, getMaintenance, voidReply } from '../../system/void.js';

const handler = async (m, { conn, args = [] }) => {
    if (!isVoid(m)) return;

    const sub = (args[0] || '').trim();

    if (sub === 'تشغيل' || sub === 'on') {
        const message = args.slice(1).join(' ') || undefined;
        setMaintenance(true, message);
        return voidReply(m, conn, `🔧 *وضع الصيانة اتفعل*\nأي حد غيرك دلوقتي هياخد رسالة صيانة لو حاول يستخدم أمر، وإنت بس اللي تقدر تستخدم البوت.\n\n📝 الرسالة: ${getMaintenance().message}`);
    }

    if (sub === 'ايقاف' || sub === 'off') {
        setMaintenance(false);
        return voidReply(m, conn, '✅ *وضع الصيانة اتقفل* - البوت رجع يشتغل للكل عادي');
    }

    const st = getMaintenance();
    return voidReply(m, conn, `🔧 *حالة الصيانة:* ${st.active ? 'شغالة ✅' : 'مقفولة ❌'}${st.active ? `\n📝 الرسالة: ${st.message}` : ''}\n\nللتشغيل: *.صيانة تشغيل [رسالة اختيارية]*\nللإيقاف: *.صيانة ايقاف*`);
};

handler.usage = ['صيانة'];
handler.desc = 'وضع الصيانة - يقفل البوت عن الكل غيرك 🔧';
handler.category = 'void';
handler.command = ['صيانة'];
handler.usePrefix = true;

export default handler;
