// plugins/void/freeze.js
// 🧊 .تجميد [دقايق] [سبب] - يوقف كل الأوامر في الجروب ده مؤقتًا (من غير طرد أو قفل فعلي)
// 🧊 .الغاء_تجميد - يفك التجميد فورًا
import { isVoid, freezeChat, unfreezeChat, isFrozen, voidReply } from '../../system/void.js';

const toEn = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

const handler = async (m, { conn, command, args = [] }) => {
    if (!isVoid(m)) return; // صامت تمامًا لأي حد غير صاحب Void

    if (command === 'الغاء_تجميد' || command === 'فك_التجميد') {
        const f = isFrozen(m.chat);
        if (!f) return voidReply(m, conn, 'ℹ️ الجروب ده مش مجمد أصلاً');
        unfreezeChat(m.chat);
        return voidReply(m, conn, '✅ *اتفك التجميد* - البوت رجع يشتغل عادي هنا');
    }

    // .تجميد [دقايق] [سبب]
    const a = args.map(toEn);
    const minutes = /^\d+$/.test(a[0] || '') ? Number(a.shift()) : 0; // 0 = لحد ما يتفك يدوي
    const reason = a.join(' ') || 'بدون سبب';

    freezeChat(m.chat, minutes, reason, m.sender);
    const dur = minutes > 0 ? `${minutes} دقيقة` : 'لحد ما تفكه بنفسك (.الغاء_تجميد)';
    return voidReply(m, conn, `🧊 *اتجمد الجروب ده*\n⏳ المدة: ${dur}\n📝 السبب: ${reason}\n\n_كل الأوامر هتتوقف هنا لحد ما يتفك، إنت بس اللي تقدر تستخدم البوت فيه._`);
};

handler.usage = ['تجميد', 'الغاء_تجميد'];
handler.descs = { 'تجميد': 'يجمد الجروب مؤقتًا (بدون طرد)', 'الغاء_تجميد': 'يفك تجميد الجروب' };
handler.desc = 'تجميد مؤقت للجروب 🧊';
handler.category = 'void';
handler.command = ['تجميد', 'الغاء_تجميد', 'فك_التجميد'];
handler.usePrefix = true;

export default handler;
