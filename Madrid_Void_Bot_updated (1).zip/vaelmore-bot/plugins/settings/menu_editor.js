// 🎨 تعديل القوائم والأسماء (للمطور بس)
// .قوائم  → لوحة التحكم     .قسم → تعديل أقسام القائمة
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { CATEGORIES } from '../../system/categories.js';
import { ui, setUi, saveUi, resetUi, FRAMES, frame, mainMenuText } from '../../system/ui.js';

const IMG_PATH = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../system/menu_header.jpg');
const toEn = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

const FIELDS = {
    'اسم':    ['brand',   'اسم البوت'],
    'مطور':   ['dev',     'اسم المطور'],
    'مملكة':  ['kingdom', 'اسم المملكة (فوق كل إطار)'],
    'عنوان':  ['title',   'عنوان القايمة الرئيسية'],
    'فوتر':   ['footer',  'كلمة التوقيع (تحت الإطارات)'],
    'اختيار': ['pick',    'جملة "اختر القسم..."'],
    'زر':     ['button',  'اسم زر الأقسام']
};

const help = () => {
    const c = ui();
    return `🎨 *لوحة تحكم القوائم*

*الإعدادات الحالية:*
• اسم البوت: ${c.brand}
• المطور: ${c.dev}
• المملكة: ${c.kingdom}
• العنوان: ${c.title}
• التوقيع: ${c.footer}
• جملة الاختيار: ${c.pick}
• اسم الزر: ${c.button}
• الإطار: ${c.frame} (${FRAMES[c.frame]?.name})
• صورة القايمة: ${c.headerImage ? 'مخصصة ✅' : 'تلقائية'}

*الأوامر:*
• *.قوائم اسم Madrid*
• *.قوائم مطور Void*
• *.قوائم مملكة مملكة فويد*
• *.قوائم عنوان الأقسام*
• *.قوائم فوتر إدارة*
• *.قوائم اختيار <جملة>*
• *.قوائم زر <نص>*
• *.قوائم اطار 3* (من غير رقم = معاينة كل الأشكال)
• *.قوائم صورة* (ارد على صورة) أو *.قوائم صورة <رابط>* أو *.قوائم صورة حذف*
• *.قوائم معاينة* (تشوف القايمة بشكلها)
• *.قوائم اعادة* (يرجّع كل حاجة للأصل)

*الأقسام:* اكتب *.قسم* وشوف القايمة`;
};

const handler = async (m, { conn, bot, args = [], text, command }) => {
    if (!m.isOwner) return m.reply('*❌ الأمر ده للمطور بس*');
    const c = ui();

    /* ============ .قسم ============ */
    if (command === 'قسم') {
        if (!args.length) {
            let t = '📂 *أقسام القايمة*\n\n';
            for (const s of CATEGORIES) {
                const o = c.sections[s[2]] || {};
                t += `${o.emoji || s[3]} *${s[0]}* — ${o.name || s[1]} (${s[2]})${o.hidden ? ' 🙈' : ''}${o.order != null ? ` #${o.order}` : ''}\n`;
            }
            return m.reply(t + '\n*التعديل:*\n• *.قسم 16 اسم الألعاب*\n• *.قسم 16 ايموجي 🎮*\n• *.قسم 16 اخفاء* / *اظهار*\n• *.قسم 16 ترتيب 1*\n• *.قسم 16 اعادة*\n(الرقم أو المفتاح زي game)');
        }
        const ref = toEn(args[0]);
        const cat = CATEGORIES.find(x => String(x[0]) === ref || x[2] === ref.toLowerCase());
        if (!cat) return m.reply('❌ القسم ده مش موجود، اكتب *.قسم* وشوف القايمة');
        const sub = args[1];
        const val = args.slice(2).join(' ').trim();
        const o = c.sections[cat[2]] || (c.sections[cat[2]] = {});
        if (sub === 'اسم') { if (!val) return m.reply('✏️ اكتب الاسم الجديد'); o.name = val; }
        else if (sub === 'ايموجي' || sub === 'إيموجي') { if (!val) return m.reply('✏️ اكتب الإيموجي'); o.emoji = val; }
        else if (sub === 'اخفاء' || sub === 'إخفاء') o.hidden = true;
        else if (sub === 'اظهار' || sub === 'إظهار') o.hidden = false;
        else if (sub === 'ترتيب') { const n = parseInt(toEn(val)); if (!Number.isFinite(n)) return m.reply('✏️ اكتب رقم الترتيب'); o.order = n; }
        else if (sub === 'اعادة' || sub === 'إعادة') delete c.sections[cat[2]];
        else return m.reply('❌ اكتب: اسم / ايموجي / اخفاء / اظهار / ترتيب / اعادة');
        saveUi();
        return m.reply(`✅ اتعدّل قسم *${cat[0]}* (${cat[2]})\nاكتب *.اوامر* وشوف التغيير`);
    }

    /* ============ .قوائم ============ */
    const sub = args[0];
    if (!sub) return m.reply(help());
    const val = args.slice(1).join(' ').trim();

    if (FIELDS[sub]) {
        if (!val) return m.reply(`✏️ اكتب القيمة الجديدة: *.قوائم ${sub} <نص>*`);
        setUi(FIELDS[sub][0], val);
        return m.reply(`✅ ${FIELDS[sub][1]} بقى: *${val}*`);
    }

    if (sub === 'اطار' || sub === 'إطار') {
        const n = parseInt(toEn(val));
        if (!n) {
            const s = Object.entries(FRAMES).map(([k, f]) => `*${k}) ${f.name}*\n${f.open}\n  نص تجريبي\n${f.close}`).join('\n\n');
            return m.reply(`🖼️ *أشكال الإطار:*\n\n${s}\n\nللاختيار: *.قوائم اطار 3*`);
        }
        if (!FRAMES[n]) return m.reply('❌ اختار رقم من 1 لـ 5');
        setUi('frame', n);
        return m.reply(`✅ الإطار بقى *${n}) ${FRAMES[n].name}*\n\n${frame('معاينة', '✨', ['كده شكل الألعاب والقوائم'])}`);
    }

    if (sub === 'صورة') {
        if (val === 'حذف') { setUi('headerImage', ''); return m.reply('🗑️ رجّعت صورة القايمة التلقائية'); }
        if (/^https?:\/\//i.test(val)) { setUi('headerImage', val); return m.reply('✅ صورة القايمة اتغيّرت (رابط)\nاكتب *.اوامر* وشوفها'); }
        const q = m.quoted || m;
        if (!/image/.test(q.mimetype || '')) return m.reply('🖼️ ارد على صورة بـ *.قوائم صورة* أو حط رابط صورة بعدها');
        const media = await q.download();
        fs.writeFileSync(IMG_PATH, media);
        setUi('headerImage', IMG_PATH);
        return m.reply('✅ صورة القايمة اتغيّرت!\nاكتب *.اوامر* وشوفها');
    }

    if (sub === 'معاينة') {
        const demo = CATEGORIES.slice(0, 4).map(s => ({ emoji: s[3], name: s[1], count: 5 }));
        return m.reply(mainMenuText({ mention: m.sender.split('@')[0], sections: demo }));
    }

    if (sub === 'عرض') return m.reply(help());

    if (sub === 'اعادة' || sub === 'إعادة') { resetUi(); return m.reply('♻️ رجّعت كل إعدادات القوائم للأصل'); }

    return m.reply('❌ أمر مش معروف. اكتب *.قوائم* وشوف الأوامر');
};

handler.usage = ['قوائم', 'قسم'];
handler.desc = 'تعديل شكل القوائم والأسماء 🎨';
handler.category = 'settings';
handler.command = ['قوائم', 'قسم'];
handler.owner = true;
export default handler;
