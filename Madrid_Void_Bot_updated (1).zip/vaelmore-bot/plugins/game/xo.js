// ❌⭕ اكس أو بين لاعبين: .اكس ثم الخصم يكتب .العب، والحركات بأرقام 1-9
import { uidOf, getPlayer, fmt, save } from '../../system/economy.js';
import { GAME } from '../../system/game_config.js';
import { frame, short } from '../../system/ui.js';
import { registerWithdraw, active } from '../../system/games_hub.js';
import { applyMultiplier } from '../../system/void.js';

const games = (global.__madridXO ||= new Map());   // chat -> لعبة
const LINES = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const NUM = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣'];
const render = b => [0, 3, 6].map(i => b.slice(i, i + 3).map((c, j) => c ? (c === 'X' ? '❌' : '⭕') : NUM[i + j]).join('')).join('\n');
const tag = p => `@${p.jid.split('@')[0].split(':')[0]}`;
const winner = b => LINES.some(([a, c, d]) => b[a] && b[a] === b[c] && b[a] === b[d]);
const toEn = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

const say = (g, text) => g.conn.sendMessage(g.chat, { text, mentions: [g.x.jid, g.o?.jid].filter(Boolean) }).catch(() => {});
const end = g => { clearTimeout(g.timer); games.delete(g.chat); active.delete(g.chat); };
const arm = (g, sec) => {
    clearTimeout(g.timer);
    g.timer = setTimeout(() => {
        if (!games.has(g.chat)) return;
        end(g);
        say(g, g.state === 'waiting' ? '⌛ محدش انضم، اتلغت لعبة اكس أو' : '⏰ اللعبة اتلغت لعدم التفاعل');
    }, sec * 1000);
};

registerWithdraw('xo', async m => {
    const g = games.get(m.chat);
    if (!g) return null;
    const uid = await uidOf(m, g.conn);
    if (g.x.uid !== uid && g.o?.uid !== uid) return null;
    const playing = g.state === 'playing';
    end(g);
    return playing ? '🏳️ انسحبت من اكس أو، واللعبة خلصت (من غير جايزة)' : '🏳️ لغيت لعبة اكس أو';
});

const handler = async (m, { conn, command }) => {
    const uid = await uidOf(m, conn);
    if (!uid) return;
    getPlayer(uid, m);
    const g = games.get(m.chat);

    if (command === 'اكس' || command === 'xo' || command === 'اكس_او') {
        if (g || active.has(m.chat)) return m.reply('🎮 فيه لعبة شغالة هنا بالفعل!');
        const ng = { chat: m.chat, conn, state: 'waiting', x: { uid, jid: m.sender }, o: null, board: Array(9).fill(null), turn: 'X' };
        games.set(m.chat, ng); active.set(m.chat, 'xo'); arm(ng, 120);
        return conn.sendMessage(m.chat, {
            text: frame('اكس أو', '❌', [`${tag(ng.x)} بدأ لعبة ومستني خصم!`, '', 'اللي عايز يلعب يكتب *.العب* 🎮', `💰 الفايز بياخد 💎 ${short(applyMultiplier(GAME.xo.reward, { chatId: m.chat, game: 'اكس_او' }))}`]),
            mentions: [m.sender]
        }, { quoted: m });
    }

    // .العب
    if (!g || g.state !== 'waiting') return m.reply('❌⭕ مفيش لعبة اكس أو مستنية لاعب. اكتب *.اكس* وابدأ واحدة');
    if (g.x.uid === uid) return m.reply('😂 انت اللي بادئ اللعبة، استنى حد يدخل');
    g.o = { uid, jid: m.sender }; g.state = 'playing'; g.conn = conn;
    arm(g, GAME.xo.moveSec);
    return conn.sendMessage(m.chat, {
        text: frame('اكس أو', '❌', [`${tag(g.x)} ❌  ضد  ${tag(g.o)} ⭕`, '', render(g.board), '', `👉 دور ${tag(g.x)} ❌ — اكتب رقم المربع (1-9)`]),
        mentions: [g.x.jid, g.o.jid]
    }, { quoted: m });
};

// الحركات: رسالة فيها رقم 1-9 من صاحب الدور
handler.before = async (m, { conn } = {}) => {
    try {
        if (!m.text || m.isCommand || m.fromMe) return false;
        const g = games.get(m.chat);
        if (!g || g.state !== 'playing') return false;
        const t = toEn(m.text.trim());
        if (!/^[1-9]$/.test(t)) return false;
        const uid = await uidOf(m, conn);
        const cur = g.turn === 'X' ? g.x : g.o;
        if (cur.uid !== uid) return false;
        const i = Number(t) - 1;
        if (g.board[i]) { await m.reply('❌ المربع ده مشغول، اختار مربع تاني'); return true; }
        g.board[i] = g.turn;

        if (winner(g.board)) {
            end(g);
            const p = getPlayer(cur.uid, m);
            const reward = applyMultiplier(GAME.xo.reward, { chatId: m.chat, game: 'اكس_او' });
            p.money += reward; p.wins = (p.wins || 0) + 1; save();
            await conn.sendMessage(m.chat, {
                text: frame('اكس أو', '❌', [render(g.board), '', `🏆 *${tag(cur)} فاز!* 🎉`, `💰 كسب 💎 ${short(reward)}`]),
                mentions: [cur.jid]
            }, { quoted: m });
            return true;
        }
        if (g.board.every(Boolean)) {
            end(g);
            await m.reply(frame('اكس أو', '❌', [render(g.board), '', '🤝 *تعادل!* محدش كسب']));
            return true;
        }
        g.turn = g.turn === 'X' ? 'O' : 'X';
        const next = g.turn === 'X' ? g.x : g.o;
        arm(g, GAME.xo.moveSec);
        await conn.sendMessage(m.chat, {
            text: frame('اكس أو', '❌', [render(g.board), '', `👉 دور ${tag(next)} ${g.turn === 'X' ? '❌' : '⭕'}`]),
            mentions: [next.jid]
        }, { quoted: m });
        return true;
    } catch { return false; }
};

handler.usage = ['اكس', 'العب'];
handler.desc = 'اكس أو بين لاعبين ❌⭕';
handler.descs = { 'اكس': 'ابدأ لعبة اكس أو', 'العب': 'انضم للعبة اكس أو' };
handler.category = 'game';
handler.command = ['اكس', 'xo', 'اكس_او', 'العب'];
export default handler;
