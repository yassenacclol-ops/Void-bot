// 🎌 لعبة خمّن العلم: .علم سهل | .علم متوسط | .علم صعب
// الوقت 30 ثانية (الجايزة 10K)، بعدها بتظهر 4 اختيارات (الجايزة 5K)، أو اكتب "خيارات" في أي وقت
import { COUNTRIES, flagEmoji } from '../../src/game/flags.js';
import { uidOf, getPlayer, fmt, save } from '../../system/economy.js';
import { GAME } from '../../system/game_config.js';
import { ui, frame, short } from '../../system/ui.js';
import { registerWithdraw, active } from '../../system/games_hub.js';
import { applyMultiplier } from '../../system/void.js';

const F = GAME.flag;
const games = (global.__madridFlag ||= new Map());      // chat -> لعبة شغالة

const norm = s => String(s || '').trim().toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/\s+/g, ' ');
const key = s => norm(s).replace(/(^|\s)ال/g, '$1').replace(/\s+/g, '');
const lev = (a, b) => {
    const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
    let prev = Array.from({ length: n + 1 }, (_, i) => i);
    for (let i = 1; i <= m; i++) { const cur = [i]; for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; }
    return prev[n];
};
const shuffle = arr => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const toEn = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

const LEVELS = { 'سهل': 'easy', 'سهله': 'easy', 'متوسط': 'medium', 'وسط': 'medium', 'صعب': 'hard', 'صعبه': 'hard' };
const LEVEL_NAMES = { easy: 'سهل', medium: 'متوسط', hard: 'صعب' };

// كل أسماء الدول (متطبّعة) - عشان نعرف إن اللي كتبه "تخمين" فعلاً مش كلام عادي
const ALL_KEYS = new Set(COUNTRIES.flatMap(c => [c.name, ...c.aliases].map(key)));

const tagOf = jid => `@${String(jid).split('@')[0].split(':')[0]}`;

const fetchImage = async code => {
    const res = await fetch(`https://flagcdn.com/w640/${code}.png`, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return Buffer.from(await res.arrayBuffer());
};

const finish = g => { g.timers.forEach(clearTimeout); games.delete(g.chat); active.delete(g.chat); };

const isNear = (g, k) => {
    if (k.length < 2) return false;
    for (const a of g.answers) {
        if (lev(a, k) <= (a.length >= 5 ? 2 : 1)) return true;
        if (k.length >= 3 && (a.includes(k) || k.includes(a))) return true;
    }
    return false;
};

// بيظهر الاختيارات (أزرار) والجايزة بتبقى 5K
const showOptions = async (g, why) => {
    if (g.hinted || !games.has(g.chat)) return;
    g.hinted = true;
    const pool = COUNTRIES.filter(c => c.level === g.country.level && c.code !== g.country.code);
    g.options = shuffle([g.country, ...shuffle(pool).slice(0, 3)]);
    g.correct = g.options.findIndex(o => o.code === g.country.code) + 1;
    const body = frame('لعبة خمّن العلم', '🎌', [
        why === 'time' ? '⏰ *انتهى الوقت!* معاك تلميح:' : '💡 *تلميح!* اختار الإجابة:',
        '',
        ...g.options.map((o, i) => `${i + 1}) ${o.name}`),
        '',
        `💰 *الجائزة دلوقتي:* 💎 ${short(applyMultiplier(F.rewardHint, { chatId: g.chat, game: 'فلاج' }))}`,
        `⏳ *باقي:* ${Math.max(1, Math.ceil((g.endAt - Date.now()) / 1000))} ثانية`
    ]);
    try {
        await g.conn.sendButton(g.chat, {
            bodyText: body,
            footerText: ui().brand,
            buttons: g.options.map((o, i) => ({ name: 'quick_reply', params: { display_text: `${i + 1}) ${o.name}`, id: `.علم_خيار ${i + 1}` } })),
            interactiveConfig: { buttons_limits: 4 }
        }, g.quoted);
    } catch {
        await g.conn.sendMessage(g.chat, { text: body + '\n\n_اكتب رقم الاختيار أو اسم الدولة_' }, { quoted: g.quoted }).catch(() => {});
    }
};

const timeUp = g => {
    if (!games.has(g.chat)) return;
    finish(g);
    g.conn.sendMessage(g.chat, {
        text: frame('لعبة خمّن العلم', '🎌', [
            '⏰ *انتهى الوقت!*', '',
            `✅ *الإجابة:* ${flagEmoji(g.country.code)} ${g.country.name}`,
            `👤 *المقدم:* ${tagOf(g.starter)}`
        ]), mentions: [g.starter]
    }).catch(() => {});
};

const win = async (m, g, winnerUid) => {
    const reward = applyMultiplier(g.hinted ? F.rewardHint : F.rewardFull, { chatId: m.chat, game: 'فلاج' });
    const p = getPlayer(winnerUid, m);
    p.money += reward; p.wins = (p.wins || 0) + 1; save();
    finish(g);
    await g.conn.sendMessage(g.chat, {
        text: frame('لعبة خمّن العلم', '🎌', [
            '🎉 *إجابة صحيحة!*', '',
            `👤 *الفائز:* ${tagOf(m.sender)}`,
            `✅ *الإجابة:* ${flagEmoji(g.country.code)} ${g.country.name}`,
            `💰 *الجائزة:* 💎 ${short(reward)}${g.hinted ? ' (مع التلميح)' : ''}`
        ]), mentions: [m.sender]
    }, { quoted: m });
};

registerWithdraw('flag', m => {
    const g = games.get(m.chat);
    if (!g) return null;
    finish(g);
    return `🏳️ تم الانسحاب!\n✅ العلم كان: ${flagEmoji(g.country.code)} *${g.country.name}*`;
});

const handler = async (m, { conn, args = [], command }) => {
    // زر اختيار من الأزرار
    if (command === 'علم_خيار') {
        const g = games.get(m.chat);
        if (!g || !g.hinted) return;
        const n = parseInt(toEn(args[0]));
        if (n === g.correct) return win(m, g, await uidOf(m, conn));
        return m.reply('❌ اختيار غلط، جرب تاني!');
    }

    let level = 'medium';
    if (args[0]) {
        level = LEVELS[norm(args[0])];
        if (!level) return m.reply('🎌 اكتب مستوى صح:\n*.علم سهل*\n*.علم متوسط*\n*.علم صعب*');
    }
    if (active.has(m.chat)) return m.reply('🎮 فيه لعبة شغالة هنا دلوقتي! جاوب عليها أو اكتب *انسحب*');

    const c = pick(COUNTRIES.filter(x => x.level === level));
    const g = {
        chat: m.chat, conn, quoted: m, starter: m.sender, country: c, level,
        answers: new Set([c.name, ...c.aliases].map(key)), hinted: false, options: null, correct: -1, timers: [],
        endAt: Date.now() + (F.timeSec + F.hintExtraSec) * 1000
    };
    games.set(m.chat, g);     // قبل أي await عشان نمنع بدء لعبتين
    active.set(m.chat, 'flag');

    const caption = frame('لعبة خمّن العلم', '🎌', [
        '🎌 *خمّن اسم الدولة!*', '',
        `⭐ *المستوى:* ${LEVEL_NAMES[level]}`,
        `👤 *المقدم:* ${tagOf(m.sender)}`,
        `💰 *الجائزة:* 💎 ${short(applyMultiplier(F.rewardFull, { chatId: m.chat, game: 'فلاج' }))}`, '',
        `⏳ *الوقت:* ${F.timeSec} ثانية`,
        '🎯 *اكتب:* خيارات (لتظهر الأزرار)',
        `💡 *تلميح بعد انتهاء الوقت:* 💎 ${short(applyMultiplier(F.rewardHint, { chatId: m.chat, game: 'فلاج' }))}`, '',
        '🛑 *للانسحاب اكتب:* انسحب'
    ]);
    try {
        let buf = null;
        try { buf = await fetchImage(c.code); } catch {}
        if (buf) await conn.sendMessage(m.chat, { image: buf, caption, mentions: [m.sender] }, { quoted: m });
        else await conn.sendMessage(m.chat, { text: `${caption}\n\n(الصورة مجتش من النت، ده العلم: ${flagEmoji(c.code)})`, mentions: [m.sender] }, { quoted: m });
    } catch (e) { games.delete(m.chat); active.delete(m.chat); throw e; }

    g.timers.push(setTimeout(() => showOptions(g, 'time'), F.timeSec * 1000));
    g.timers.push(setTimeout(() => timeUp(g), (F.timeSec + F.hintExtraSec) * 1000));
};

// استقبال الإجابات (أي حد في الشات يقدر يجاوب) + كلمة "خيارات"
handler.before = async (m, { conn } = {}) => {
    try {
        if (!m.text || m.isCommand || m.fromMe) return false;
        const g = games.get(m.chat);
        if (!g) return false;
        const t = toEn(m.text.trim());
        if (t.length > 40 || t.includes('\n')) return false;
        if (t === 'انسحب') return false;

        if (t === 'خيارات' || t === 'الخيارات') { await showOptions(g, 'ask'); return true; }

        if (g.hinted && /^[1-4]$/.test(t)) {
            if (Number(t) === g.correct) { await win(m, g, await uidOf(m, conn)); return true; }
            await m.reply('❌ اختيار غلط، جرب تاني!'); return true;
        }
        const k = key(t);
        if (!k) return false;
        if (g.answers.has(k)) { await win(m, g, await uidOf(m, conn)); return true; }
        // نرد "غلط" بس لو كان تخمين حقيقي (اسم دولة تانية أو قريب من الإجابة)
        if (ALL_KEYS.has(k)) { await m.reply('❌ إجابة غلط'); return true; }
        if (isNear(g, k)) { await m.reply('❌ إجابة غلط، بس قربت 👀🔥'); return true; }
        return false;
    } catch { return false; }
};

handler.usage = ['علم'];
handler.desc = 'خمّن العلم (سهل/متوسط/صعب) 🎌';
handler.descs = { 'علم': 'خمّن العلم: سهل / متوسط / صعب' };
handler.category = 'game';
handler.command = ['علم', 'علم_خيار'];
export default handler;
