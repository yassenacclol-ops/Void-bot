// 🌾 لعبة المزرعة - فلوسها هي نقاط البوت كله (system/economy.js)
// الأوامر: .مزرعة .متجر .شراء .زرع .سقي .حصاد .مخزون .بيع .ترقية .اسم_المزرعة
import { DB, fmt, uidOf, getPlayer, moneyText, spend, save } from '../../system/economy.js';
import { GAME } from '../../system/game_config.js';
import { applyMultiplier } from '../../system/void.js';

const MAX_PLANTS = GAME.farm.maxPlants;
const SPOIL_CHANCE = GAME.farm.spoilChance;
const NAME_MIN = 2, NAME_MAX = 25, PENDING_MS = 2 * 60 * 1000;

// ✏️ المحاصيل: سعر البذرة / سعر البيع / وقت النضج بالثواني
const CROPS = [
    { name: 'خس',     emoji: '🥬', seed: 50,    sell: 200,   secs: 30  },
    { name: 'جزر',    emoji: '🥕', seed: 120,   sell: 450,   secs: 45  },
    { name: 'قمح',    emoji: '🌾', seed: 500,   sell: 2000,  secs: 60  },
    { name: 'طماطم',  emoji: '🍅', seed: 900,   sell: 3600,  secs: 90  },
    { name: 'ذرة',    emoji: '🌽', seed: 1500,  sell: 6000,  secs: 120 },
    { name: 'بطاطس',  emoji: '🥔', seed: 2500,  sell: 10000, secs: 180 },
    { name: 'بطيخ',   emoji: '🍉', seed: 5000,  sell: 20000, secs: 300 },
    { name: 'فراولة', emoji: '🍓', seed: 10000, sell: 40000, secs: 480 },
];
// ✏️ الترقيات (السعر = base × (المستوى+1)²)
const UPGRADES = [
    { key: 'land',  label: '🏞️ الأرض',     names: ['ارض', 'الارض', 'أرض', 'الأرض'], max: 10, base: 5000, desc: '+10 مكان للنباتات كل مستوى' },
    { key: 'speed', label: '🧪 السماد',    names: ['سماد', 'السماد', 'تسريع'],      max: 5,  base: 8000, desc: 'النبات بينضج أسرع 8% كل مستوى' },
    { key: 'irrig', label: '💧 نظام الري', names: ['ري', 'الري', 'نظام_الري'],     max: 5,  base: 6000, desc: 'احتمال الفساد أقل 5% كل مستوى' },
];

const norm = s => String(s || '').trim().toLowerCase()
    .replace(/[\u064B-\u065F\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');
const toEn = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const dur = ms => {
    const s = Math.max(0, Math.ceil(ms / 1000));
    if (s < 60) return `${s} ثانية`;
    const mi = Math.floor(s / 60), r = s % 60;
    const mt = mi === 1 ? 'دقيقة' : mi === 2 ? 'دقيقتين' : `${mi} دقايق`;
    return r ? `${mt} و${r} ثانية` : mt;
};
const findCrop = n => CROPS.find(c => norm(c.name) === norm(n));
const cropList = () => CROPS.map(c => `${c.emoji} ${c.name}`).join(' • ');

const lvl = (p, k) => p[k] || 0;
const capOf = p => MAX_PLANTS + 10 * lvl(p, 'land');
const speedMul = p => 1 - 0.08 * lvl(p, 'speed');
const spoilOf = p => Math.max(0, SPOIL_CHANCE - 0.05 * lvl(p, 'irrig'));
const upCost = (p, u) => u.base * (lvl(p, u.key) + 1) ** 2;
const totalPlants = p => p.plots.reduce((a, x) => a + x.count, 0);

const pending = new Map();                                   // uid -> { chat, at }
const conns = (global.__madridFarmConns ||= new Map());      // chat -> conn

const settle = (p, now = Date.now()) => {
    for (const x of p.plots) {
        if (x.state !== 'growing') continue;
        if (x.spoilAt && !x.watered && now >= x.spoilAt) x.state = 'spoiled';
        else if (now >= x.readyAt) x.state = 'ripe';
    }
};

/* ===== إشعارات تلقائية: تحذير / نضج / فساد ===== */
const tick = async () => {
    const now = Date.now();
    let dirty = false;
    for (const [uid, p] of Object.entries(DB.users)) {
        if (!p.plots?.length) continue;
        settle(p, now);
        const byChat = new Map();
        const add = (x, line) => {
            if (!byChat.has(x.chat)) byChat.set(x.chat, { lines: [], plots: [] });
            const e = byChat.get(x.chat); e.lines.push(line); e.plots.push(x);
        };
        for (const x of p.plots) {
            const c = findCrop(x.crop);
            const tag = `${c.emoji} ${x.crop} ×${x.count}`;
            if (x.state === 'growing' && x.spoilAt && !x.watered && !x.warned && now >= x.warnAt)
                add(x, `⚠️ ${tag} هيفسد بعد ${dur(x.spoilAt - now)}`);
            else if (x.state === 'ripe' && !x.announced) add(x, `✅ ${tag} نضج! اكتب *.حصاد*`);
            else if (x.state === 'spoiled' && !x.announced) add(x, `🥀 ${tag} فسد وراح عليك`);
        }
        for (const [chat, { lines, plots }] of byChat) {
            const conn = conns.get(chat);
            if (!conn) continue;
            const warn = lines.some(l => l.startsWith('⚠️'));
            const text = `@${uid}\n\n${lines.join('\n')}` + (warn ? '\n\n💧 اكتب *.سقي* دلوقتي عشان تنقذهم!' : '');
            try { await conn.sendMessage(chat, { text, mentions: p.jid ? [p.jid] : [] }); } catch { continue; }
            dirty = true;
            for (const x of plots) { if (x.state === 'growing') x.warned = true; else x.announced = true; }
        }
        const before = p.plots.length;
        p.plots = p.plots.filter(x => !(x.state === 'spoiled' && x.announced));
        if (p.plots.length !== before) dirty = true;
    }
    if (dirty) save();
};
if (global.__madridFarmTicker) clearInterval(global.__madridFarmTicker);
global.__madridFarmTicker = setInterval(() => tick().catch(() => {}), 5000);
global.__madridFarmTicker.unref?.();

/* ===== شاشات ===== */
const HELP = '📌 *.متجر* • *.شراء* • *.زرع* • *.سقي* • *.حصاد* • *.مخزون* • *.بيع* • *.ترقية*';

const farmText = (p, m) => {
    const now = Date.now();
    let t = `🌾 *${p.name}* 🌾\n💰 فلوسك: *${moneyText(p, m)}*\n\n🌱 *الأرض* (${totalPlants(p)}/${capOf(p)}):\n`;
    if (!p.plots.length) t += '• فاضية، اشتري بذور من *.متجر* وازرع 🌱\n';
    for (const x of p.plots) {
        const c = findCrop(x.crop);
        let st;
        if (x.state === 'ripe') st = '✅ جاهز للحصاد';
        else if (x.state === 'spoiled') st = '🥀 فسد';
        else st = `⏳ ${dur(x.readyAt - now)}` + (x.watered ? ' 💧' : '') + (x.warned && !x.watered ? ' ⚠️ هيفسد!' : '');
        t += `• ${c.emoji} ${x.crop} ×${x.count} — ${st}\n`;
    }
    return t + '\n' + HELP;
};

const shopText = (p, m) => {
    let t = `🛒 *متجر البذور*\n💰 فلوسك: *${moneyText(p, m)}*\n\n`;
    for (const c of CROPS)
        t += `${c.emoji} *${c.name}*\n   🌱 البذرة: ${fmt(c.seed)}  |  💵 بتتباع: ${fmt(c.sell)}  |  ⏳ ${dur(c.secs * 1000 * speedMul(p))}\n`;
    return t + '\nللشراء: *.شراء قمح 3*\nللزرع: *.زرع قمح 3*\nلبيع المحصول: *.بيع قمح 3*';
};

const parse = args => {
    const a = args.map(toEn);
    const nums = a.filter(x => /^\d+$/.test(x));
    return { name: a.filter(x => !/^\d+$/.test(x)).join(' '), has: nums.length > 0, count: nums.length ? Number(nums[0]) : 1 };
};

const ACTIONS = {
    'مزرعه': 'farm', 'متجر': 'shop', 'شراء': 'buy', 'زرع': 'plant', 'سقي': 'water', 'حصاد': 'harvest',
    'مخزون': 'inv', 'بيع': 'sell', 'ترقيه': 'up', 'ترقيات': 'up', 'اسم_المزرعه': 'rename'
};

const handler = async (m, { conn, args = [], command }) => {
    conns.set(m.chat, conn);
    const act = ACTIONS[norm(command)];
    if (!act) return;
    const uid = await uidOf(m, conn);
    if (!uid) return m.reply('⚠️ مقدرتش أحدد حسابك، جرب تاني');
    const p = getPlayer(uid, m);

    // أول مرة: نطلب اسم المزرعة (المطور مزرعته جاهزة)
    if (!p.name) {
        if (act !== 'farm') return m.reply('🌱 معندكش مزرعة لسه! اكتب *.مزرعة* الأول');
        pending.set(uid, { chat: m.chat, at: Date.now() });
        return m.reply('*معلش دي أول مرة ليك، اكتب اسم مزرعتك* 🌾');
    }
    settle(p);
    const { name, has, count } = parse(args);

    switch (act) {
        case 'farm': save(); return m.reply(farmText(p, m));
        case 'shop': return m.reply(shopText(p, m));

        case 'rename': {
            const n = args.join(' ').replace(/\s+/g, ' ').trim();
            if (n.length < NAME_MIN || n.length > NAME_MAX) return m.reply(`✏️ اكتب كده: *.اسم_المزرعة اسم جديد* (من ${NAME_MIN} لـ ${NAME_MAX} حرف)`);
            p.name = n; save();
            return m.reply(`✅ مزرعتك بقت *${n}*`);
        }

        case 'buy': {
            const c = findCrop(name);
            if (!name || !c) return m.reply(`🛒 اكتب كده: *.شراء قمح 3*\n\nالمتاح: ${cropList()}`);
            if (!Number.isSafeInteger(count) || count < 1 || count > 100000) return m.reply('❌ اكتب عدد صحيح صح يا معلم');
            const cost = c.seed * count;
            if (!spend(p, m, cost)) return m.reply(`❌ فلوسك مش كفاية!\nمحتاج *${fmt(cost)}* وعندك *${moneyText(p, m)}* 💸`);
            p.seeds[c.name] = (p.seeds[c.name] || 0) + count; save();
            return m.reply(`✅ اشتريت *${count}* بذرة ${c.emoji} ${c.name}\n💸 دفعت: ${m.isOwner ? '∞' : fmt(cost)}\n💰 فلوسك: *${moneyText(p, m)}*\n\nازرعها بـ *.زرع ${c.name} ${count}*`);
        }

        case 'plant': {
            const c = findCrop(name);
            if (!name || !c) return m.reply(`🌱 اكتب كده: *.زرع قمح 1*\n\nالمتاح: ${cropList()}`);
            if (!Number.isSafeInteger(count) || count < 1) return m.reply('❌ اكتب عدد صحيح صح يا معلم');
            const have = p.seeds[c.name] || 0;
            if (have < count) return m.reply(`❌ معندكش بذور كفاية!\nعندك *${have}* بذرة ${c.emoji} ${c.name}\nاشتري من *.متجر* 🛒`);
            const room = capOf(p) - totalPlants(p);
            if (count > room) return m.reply(`❌ الأرض مش هتشيل كده!\nفاضل فيها مكان لـ *${Math.max(0, room)}* نبات بس (الحد ${capOf(p)}، رقّي الأرض بـ *.ترقية*)`);
            const now = Date.now(), grow = Math.round(c.secs * 1000 * speedMul(p));
            const willSpoil = Math.random() < spoilOf(p);
            const spoilAt = willSpoil ? now + Math.floor(grow * 0.8) : 0;
            const lead = Math.min(60000, Math.floor(grow * 0.4)); // تحذير قبل الفساد بدقيقة (أو أقل للمحاصيل السريعة)
            p.seeds[c.name] = have - count;
            if (!p.seeds[c.name]) delete p.seeds[c.name];
            p.plots.push({
                id: now + '-' + Math.floor(Math.random() * 1e6), crop: c.name, count, chat: m.chat,
                plantedAt: now, readyAt: now + grow, spoilAt, warnAt: willSpoil ? spoilAt - lead : 0,
                watered: false, warned: false, announced: false, state: 'growing'
            });
            save();
            return m.reply(`🌱 زرعت *${count}* ${c.emoji} ${c.name}\n⏳ هتنضج بعد *${dur(grow)}*\n\n💧 اسقيهم بـ *.سقي* عشان ميفسدوش، وبعد ما ينضجوا اكتب *.حصاد*`);
        }

        case 'water': {
            const growing = p.plots.filter(x => x.state === 'growing');
            if (!growing.length) return m.reply('🌱 مفيش نباتات بتنمو دلوقتي عشان تسقيها');
            const dry = growing.filter(x => !x.watered);
            if (!dry.length) return m.reply('💧 كل نباتاتك متسقية أصلاً، متقلقش 😎');
            let n = 0;
            for (const x of dry) { x.watered = true; n += x.count; }
            save();
            return m.reply(`💧 سقيت *${n}* نبات!\nدلوقتي مفيش خطر إنهم يفسدوا ✅`);
        }

        case 'harvest': {
            const ripe = p.plots.filter(x => x.state === 'ripe');
            const spoiled = p.plots.filter(x => x.state === 'spoiled');
            if (!ripe.length && !spoiled.length) {
                const next = p.plots.filter(x => x.state === 'growing').sort((a, b) => a.readyAt - b.readyAt)[0];
                return m.reply(next ? `⏳ لسه مفيش حاجة جاهزة\nأقرب حصاد بعد *${dur(next.readyAt - Date.now())}*` : '🌱 الأرض فاضية، ازرع الأول بـ *.زرع*');
            }
            let t = '';
            if (ripe.length) {
                t += '🧺 *حصادك:*\n';
                for (const x of ripe) { p.crops[x.crop] = (p.crops[x.crop] || 0) + x.count; t += `• ${findCrop(x.crop).emoji} ${x.crop} ×${x.count}\n`; }
            }
            if (spoiled.length) {
                t += (t ? '\n' : '') + '🥀 *فسدوا:*\n';
                for (const x of spoiled) t += `• ${findCrop(x.crop).emoji} ${x.crop} ×${x.count}\n`;
            }
            p.plots = p.plots.filter(x => x.state === 'growing');
            save();
            return m.reply(t + (ripe.length ? '\nشوفهم في *.مخزون* وبيعهم بـ *.بيع*' : ''));
        }

        case 'inv': {
            let t = `🎒 *المخزون — ${p.name}*\n💰 فلوسك: *${moneyText(p, m)}*\n\n🌱 *البذور:*\n`;
            const seeds = Object.entries(p.seeds), crops = Object.entries(p.crops);
            t += seeds.length ? seeds.map(([n, q]) => `• بذور ${n} ${findCrop(n).emoji}: ${fmt(q)}`).join('\n') : '• فاضي';
            t += '\n\n🧺 *المحصول:*\n';
            t += crops.length ? crops.map(([n, q]) => `• ${n} ${findCrop(n).emoji}: ${fmt(q)}`).join('\n') : '• فاضي';
            return m.reply(t);
        }

        case 'sell': {
            if (norm(name) === norm('الكل') || (!name && !has)) {
                const entries = Object.entries(p.crops);
                if (!entries.length) return m.reply('🧺 معندكش محصول تبيعه، احصد الأول بـ *.حصاد*');
                let total = 0, t = '💵 *بعت:*\n';
                for (const [n, q] of entries) { const c = findCrop(n); const g = c.sell * q; total += g; t += `• ${c.emoji} ${n} ×${q} = ${fmt(g)}\n`; }
                total = applyMultiplier(total, { chatId: m.chat, game: 'مزرعة' });
                p.crops = {}; p.money += total; save();
                return m.reply(`${t}\n💰 كسبت *${fmt(total)}*\nفلوسك دلوقتي: *${moneyText(p, m)}*`);
            }
            const c = findCrop(name);
            if (!c) return m.reply(`💵 اكتب كده: *.بيع قمح 3* أو *.بيع الكل*\n\nالمتاح: ${cropList()}`);
            const have = p.crops[c.name] || 0;
            if (!have) return m.reply(`❌ معندكش ${c.emoji} ${c.name} في المخزون`);
            const q = has ? count : have;
            if (!Number.isSafeInteger(q) || q < 1) return m.reply('❌ اكتب عدد صحيح صح يا معلم');
            if (q > have) return m.reply(`❌ عندك *${have}* ${c.emoji} ${c.name} بس`);
            const gain = applyMultiplier(c.sell * q, { chatId: m.chat, game: 'مزرعة' });
            p.crops[c.name] = have - q;
            if (!p.crops[c.name]) delete p.crops[c.name];
            p.money += gain; save();
            return m.reply(`💵 بعت *${q}* ${c.emoji} ${c.name}\n💰 كسبت *${fmt(gain)}*\nفلوسك دلوقتي: *${moneyText(p, m)}*`);
        }

        case 'up': {
            const arg = args.join(' ');
            if (!arg) {
                let t = `⬆️ *ترقيات المزرعة*\n💰 فلوسك: *${moneyText(p, m)}*\n\n`;
                for (const u of UPGRADES) {
                    const l = lvl(p, u.key);
                    t += `${u.label} — مستوى *${l}/${u.max}*\n   ${u.desc}\n   ${l >= u.max ? '✅ وصلت للآخر' : `💵 الترقية الجاية: ${fmt(upCost(p, u))}`}\n`;
                }
                return m.reply(t + '\nللترقية: *.ترقية الارض* أو *.ترقية السماد* أو *.ترقية الري*');
            }
            const u = UPGRADES.find(x => x.names.some(n => norm(n) === norm(arg)));
            if (!u) return m.reply('❌ ترقية مش موجودة. اكتب *.ترقية* وشوف القايمة');
            const l = lvl(p, u.key);
            if (l >= u.max) return m.reply(`✅ ${u.label} وصلت لآخر مستوى أصلاً!`);
            const cost = upCost(p, u);
            if (!spend(p, m, cost)) return m.reply(`❌ فلوسك مش كفاية!\nالترقية بـ *${fmt(cost)}* وعندك *${moneyText(p, m)}* 💸`);
            p[u.key] = l + 1; save();
            return m.reply(`⬆️ *تمت الترقية!*\n${u.label} بقت مستوى *${l + 1}/${u.max}*\n💸 دفعت: ${m.isOwner ? '∞' : fmt(cost)}\n💰 فلوسك: *${moneyText(p, m)}*\n\n(الترقية بتشتغل على اللي هتزرعه من دلوقتي)`);
        }
    }
};

// استقبال اسم المزرعة (أول مرة)
handler.before = async (m, { conn } = {}) => {
    try {
        if (!pending.size || !m.text || m.isCommand || m.prefix || m.fromMe) return false;
        const now = Date.now();
        for (const [k, v] of pending) if (now - v.at > PENDING_MS) pending.delete(k);
        const uid = await uidOf(m, conn);
        const e = pending.get(uid);
        if (!e || e.chat !== m.chat) return false;
        const name = m.text.replace(/\s+/g, ' ').trim();
        if (name.length < NAME_MIN || name.length > NAME_MAX) {
            await m.reply(`❌ الاسم لازم يكون من ${NAME_MIN} لـ ${NAME_MAX} حرف، اكتب اسم تاني 🌾`);
            return true;
        }
        pending.delete(uid);
        const p = getPlayer(uid, m);
        p.name = name; save();
        await m.reply(`🎉 تمام! مزرعتك *${name}* اتعملت!\n💰 معاك *${moneyText(p, m)}* فلوس\n\nاكتب *.متجر* واشتري أول بذورك 🌱`);
        return true;
    } catch { return false; }
};

handler.usage = ['مزرعة', 'متجر', 'شراء', 'زرع', 'سقي', 'حصاد', 'مخزون', 'بيع', 'ترقية', 'اسم_المزرعة'];
handler.desc = 'لعبة المزرعة 🌾';
handler.descs = { 'مزرعة': 'مزرعتك وحالة نباتاتك', 'متجر': 'متجر البذور والأسعار', 'شراء': 'اشتري بذور', 'زرع': 'ازرع بذورك', 'سقي': 'اسقي نباتاتك (بيمنع الفساد)', 'حصاد': 'احصد الناضج', 'مخزون': 'بذورك ومحصولك', 'بيع': 'بيع المحصول', 'ترقية': 'ترقيات المزرعة', 'اسم_المزرعة': 'غيّر اسم مزرعتك' };
handler.category = 'game';
handler.command = ['مزرعة', 'مزرعه', 'متجر', 'شراء', 'زرع', 'سقي', 'سقى', 'حصاد', 'مخزون', 'بيع', 'ترقية', 'ترقيه', 'ترقيات', 'اسم_المزرعة', 'اسم_المزرعه'];

export default handler;
