// 🧠 ألعاب بنقاط: .سؤال (أسئلة) - .فكك (رتّب الحروف) - .عواصم
// البيانات من src/game (بتاعة البوت) + أسئلة عامة وكلمات إضافية
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { uidOf, getPlayer, fmt, save } from '../../system/economy.js';
import { GAME } from '../../system/game_config.js';
import { frame, short } from '../../system/ui.js';
import { registerWithdraw, active } from '../../system/games_hub.js';
import { applyMultiplier } from '../../system/void.js';

const DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../src/game');
const read = n => { try { return JSON.parse(fs.readFileSync(path.join(DIR, n), 'utf8')); } catch { return []; } };

const GENERAL = [
    ['ما هي عاصمة اليابان؟', 'طوكيو'], ['ما هو أكبر كوكب في المجموعة الشمسية؟', 'المشتري'],
    ['ما هو أقرب كوكب للشمس؟', 'عطارد'], ['كم عدد قارات العالم؟', '7', 'سبعة'],
    ['ما اسم عملة اليابان؟', 'الين'], ['في أي دولة يقع برج إيفل؟', 'فرنسا'],
    ['كم يساوي 12 × 12؟', '144'], ['كم عدد أسنان الإنسان البالغ؟', '32'],
    ['من رسم لوحة الموناليزا؟', 'ليوناردو دافنشي', 'دافنشي'], ['ما هو أسرع حيوان بري؟', 'الفهد', 'الشيتا'],
    ['ما هو المعدن السائل في درجة حرارة الغرفة؟', 'الزئبق'], ['كم عدد حروف اللغة العربية؟', '28'],
    ['ما هي أكبر قارة في العالم مساحة؟', 'آسيا'], ['ما هو أطول حيوان في العالم؟', 'الزرافة'],
    ['كم عدد أركان الإسلام؟', '5', 'خمسة'], ['ما هو أكبر محيط في العالم؟', 'المحيط الهادئ', 'الهادي', 'الهادئ'],
    ['كم عدد أيام السنة الميلادية العادية؟', '365'], ['ما هو أكبر عضو في جسم الإنسان؟', 'الجلد'],
    ['ما هو أكثر غاز في الغلاف الجوي للأرض؟', 'النيتروجين', 'النتروجين', 'الأزوت'], ['من هو أول إنسان وطأ سطح القمر؟', 'نيل أرمسترونج', 'ارمسترونج']
].map(([question, ...ans]) => ({ question, answers: ans }));

const WORDS = ['مدرسة','سيارة','طائرة','حديقة','مكتبة','برتقال','كمبيوتر','تلفزيون','مستشفى','جامعة','مفتاح','عصفور','زرافة','فراشة','قطار','دراجة','صحراء','بحيرة','مطار','ملعب','مطعم','مدينة','هاتف','نظارة','حقيبة','ثلاجة','مروحة','غسالة','بطيخ','طماطم','بطاطس','فراولة','شجرة','سحابة'];

const norm = s => String(s || '').trim().toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');
const toEn = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const key = s => norm(toEn(s)).replace(/(^|\s)ال/g, '$1').replace(/\s+/g, '');
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const shuffle = arr => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const tag = jid => `@${String(jid).split('@')[0].split(':')[0]}`;

const games = (global.__madridTrivia ||= new Map());   // chat -> لعبة
const finish = g => { clearTimeout(g.timer); games.delete(g.chat); active.delete(g.chat); };

registerWithdraw('trivia', m => {
    const g = games.get(m.chat);
    if (!g) return null;
    finish(g);
    return `🏳️ تم الانسحاب!\n✅ الإجابة كانت: *${g.main}*`;
});

const start = async (m, conn, type, arg) => {
    if (active.has(m.chat)) return m.reply('🎮 فيه لعبة شغالة هنا! جاوب عليها أو اكتب *انسحب*');
    const C = GAME[type];
    let answers, body, title, emoji;
    if (type === 'quiz') {
        const anime = norm(arg || '') === norm('انمي');
        const bank = anime ? read('anime_q.json').map(x => ({ question: x.question, answers: [x.response] }))
            : [...GENERAL, ...read('general_q.json').map(x => ({ question: x.question, answers: [x.response] }))];
        const q = pick(bank);
        answers = q.answers; title = anime ? 'سؤال أنمي' : 'سؤال'; emoji = '🧠';
        body = [`❓ *${q.question}*`];
    } else if (type === 'capitals') {
        const q = pick(read('capitals.json'));
        answers = [q.response]; title = 'عواصم'; emoji = '🏙️';
        body = [`❓ *${q.question}*`];
    } else {
        const anime = norm(arg || '') === norm('انمي');
        const w = pick(anime ? read('anime_words.json') : WORDS);
        let letters; do { letters = shuffle([...w.replace(/\s+/g, '')]); } while (letters.join('') === w.replace(/\s+/g, '') && w.length > 2);
        answers = [w]; title = 'فكك'; emoji = '🔤';
        body = ['🔤 *رتّب الحروف دي لتكوّن كلمة:*', '', `*${letters.join(' - ')}*`];
    }
    const g = { chat: m.chat, conn, starter: m.sender, main: answers[0], answers: new Set(answers.map(key)), reward: C.reward, type };
    games.set(m.chat, g); active.set(m.chat, 'trivia');
    g.timer = setTimeout(() => {
        if (!games.has(m.chat)) return;
        finish(g);
        conn.sendMessage(m.chat, { text: frame(title, emoji, ['⏰ *انتهى الوقت!*', '', `✅ *الإجابة:* ${g.main}`]) }).catch(() => {});
    }, C.timeSec * 1000);
    g.title = title; g.emoji = emoji;
    return conn.sendMessage(m.chat, {
        text: frame(title, emoji, [...body, '', `👤 *المقدم:* ${tag(m.sender)}`, `💰 *الجائزة:* 💎 ${short(applyMultiplier(C.reward, { chatId: m.chat, game: type }))}`, `⏳ *الوقت:* ${C.timeSec} ثانية`, '', '🛑 *للانسحاب اكتب:* انسحب']),
        mentions: [m.sender]
    }, { quoted: m });
};

const handler = async (m, { conn, args = [], command }) => {
    if (command === 'سؤال' || command === 'سوال') return start(m, conn, 'quiz', args[0]);
    if (command === 'فكك' || command === 'تفكيك') return start(m, conn, 'scramble', args[0]);
    if (command === 'عواصم' || command === 'عاصمة' || command === 'عاصمه') return start(m, conn, 'capitals');
};

handler.before = async (m, { conn } = {}) => {
    try {
        if (!m.text || m.isCommand || m.fromMe) return false;
        const g = games.get(m.chat);
        if (!g) return false;
        const t = m.text.trim();
        if (t.length > 60 || t.includes('\n')) return false;
        if (t === 'انسحب') return false;
        if (g.answers.has(key(t))) {
            const uid = await uidOf(m, conn);
            const p = getPlayer(uid, m);
            const reward = applyMultiplier(g.reward, { chatId: m.chat, game: g.type });
            p.money += reward; p.wins = (p.wins || 0) + 1; save();
            finish(g);
            await conn.sendMessage(m.chat, {
                text: frame(g.title, g.emoji, ['🎉 *إجابة صحيحة!*', '', `👤 *الفائز:* ${tag(m.sender)}`, `✅ *الإجابة:* ${g.main}`, `💰 *الجائزة:* 💎 ${short(reward)}`]),
                mentions: [m.sender]
            }, { quoted: m });
            return true;
        }
        // رد "غلط" للي بدأ اللعبة بس (عشان منزعجش باقي الجروب)
        if (m.sender === g.starter) { await m.reply('❌ إجابة غلط، حاول تاني!'); return true; }
        return false;
    } catch { return false; }
};

handler.usage = ['سؤال', 'فكك', 'عواصم'];
handler.desc = 'ألعاب أسئلة وفكك وعواصم 🧠';
handler.descs = { 'سؤال': 'سؤال عام (أو .سؤال انمي)', 'فكك': 'رتّب الحروف (أو .فكك انمي)', 'عواصم': 'خمّن عاصمة الدولة' };
handler.category = 'game';
handler.command = ['سؤال', 'سوال', 'فكك', 'تفكيك', 'عواصم', 'عاصمة', 'عاصمه'];
export default handler;
