// 💰 النقاط (= فلوس المزرعة): الرصيد، اليومي، التحويل، الأغنياء، الملف
import { DB, fmt, uidOf, uidOfJid, getPlayer, moneyText, isInf, save } from '../../system/economy.js';
import { GAME } from '../../system/game_config.js';
import { ui } from '../../system/ui.js';
import { applyMultiplier } from '../../system/void.js';

const DAY = 24 * 60 * 60 * 1000;
const toEn = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const dur = ms => {
    const s = Math.max(0, Math.ceil(ms / 1000));
    if (s < 60) return `${s} ثانية`;
    if (s >= 3600) {
        const h = Math.floor(s / 3600), mi = Math.floor((s % 3600) / 60);
        const ht = h === 1 ? 'ساعة' : h === 2 ? 'ساعتين' : h <= 10 ? `${h} ساعات` : `${h} ساعة`;
        return mi ? `${ht} و${mi} دقيقة` : ht;
    }
    return `${Math.floor(s / 60)} دقيقة`;
};

const handler = async (m, { conn, args = [], command }) => {
    const uid = await uidOf(m, conn);
    if (!uid) return m.reply('⚠️ مقدرتش أحدد حسابك، جرب تاني');
    const p = getPlayer(uid, m);

    switch (command) {
        case 'فلوسي': case 'نقاطي': case 'رصيدي':
            return m.reply(`💰 *نقاطك (فلوسك):* ${moneyText(p, m)}\n🏆 انتصارات الألعاب: ${p.wins || 0}\n\nالنقاط دي هي نفسها فلوس مزرعتك 🌾`);

        case 'ملفي': case 'بروفايل': {
            const lv = (k) => p[k] || 0;
            return m.reply(
`👤 *ملف ${m.pushName || 'اللاعب'}*
${ui().kingdom && isInf(p, m) ? `👑 ${ui().kingdom}\n` : ''}🌾 المزرعة: ${p.name || 'لسه معملش'}
💰 النقاط: *${moneyText(p, m)}*
🏆 الانتصارات: ${p.wins || 0}
⬆️ ترقيات: أرض ${lv('land')} • سماد ${lv('speed')} • ري ${lv('irrig')}
🔥 اليومي ورا بعض: ${p.daily?.streak || 0}`);
        }

        case 'يومي': case 'اليومي': {
            const D = GAME.daily, now = Date.now();
            const d = p.daily || (p.daily = { last: 0, streak: 0 });
            const left = d.last + DAY - now;
            if (left > 0) return m.reply(`⏳ خدت مكافأتك النهاردة!\nارجع بعد *${dur(left)}* 🎁`);
            d.streak = (d.last && now - d.last < 2 * DAY) ? Math.min(d.streak + 1, D.maxStreak) : 1;
            d.last = now;
            const reward = applyMultiplier(D.base + (d.streak - 1) * D.streakBonus, { chatId: m.chat, game: 'يومي' });
            p.money += reward; save();
            return m.reply(`🎁 *مكافأتك اليومية!*\n💰 +${fmt(reward)}\n🔥 أيام ورا بعض: *${d.streak}*/${D.maxStreak}\nنقاطك: *${moneyText(p, m)}*\n\n_كل يوم بيزيد المكافأة، وبتتصفر لو فوّت يوم_`);
        }

        case 'تحويل': case 'حول': {
            const T = GAME.transfer;
            const a = args.map(toEn);
            const nums = a.filter(x => /^\d+$/.test(x));
            const jid = m.mentionedJid?.[0] || m.quoted?.sender;
            let target = jid ? await uidOfJid(jid, conn) : null, amount;
            if (target) amount = Number(nums[nums.length - 1]);
            else { const num = nums.find(n => n.length >= 8); target = num; amount = Number(nums.find(n => n !== num)); }
            if (!target || !Number.isSafeInteger(amount))
                return m.reply('💸 اكتب كده:\n*.تحويل @فلان 500*\nأو ارد على رسالته، أو اكتب رقمه: *.تحويل 2010xxxxxxxx 500*');
            if (amount < T.min) return m.reply(`❌ أقل مبلغ للتحويل *${fmt(T.min)}*`);
            if (target === uid) return m.reply('😂 مينفعش تحول لنفسك');
            const to = DB.users[target];
            if (!to) return m.reply('❌ اللاعب ده لسه مدخلش البوت (لازم يكون جرب أي أمر قبل كده)');
            if (!isInf(p, m) && p.money < amount) return m.reply(`❌ نقاطك مش كفاية! عندك *${moneyText(p, m)}*`);
            const fee = Math.floor(amount * T.feePercent / 100);
            if (!isInf(p, m)) p.money -= amount;
            to.money += amount - fee; save();
            return conn.sendMessage(m.chat, {
                text: `✅ *تم التحويل!*\n💸 دفعت: ${isInf(p, m) ? '∞' : fmt(amount)}\n📉 رسوم (${T.feePercent}%): ${fmt(fee)}\n📥 وصل لـ @${(to.jid || target).split('@')[0]}: *${fmt(amount - fee)}*\n💰 نقاطك: *${moneyText(p, m)}*`,
                mentions: to.jid ? [to.jid] : []
            }, { quoted: m });
        }

        case 'الاغنياء': case 'اغنياء': case 'متصدرين': case 'المتصدرين': {
            const top = Object.entries(DB.users)
                .sort((x, y) => (y[1].inf ? 1 : 0) - (x[1].inf ? 1 : 0) || y[1].money - x[1].money).slice(0, 10);
            if (!top.length) return m.reply('🏆 لسه مفيش لاعبين');
            const medals = ['🥇', '🥈', '🥉'];
            const lines = top.map(([id, q], i) =>
                `${medals[i] || `${i + 1}.`} ${q.name || 'لاعب ••' + id.slice(-4)} — ${q.inf ? '∞' : fmt(q.money)}`);
            return m.reply(`🏆 *أغنى اللاعبين*\n\n${lines.join('\n')}`);
        }
    }
};

handler.usage = ['نقاطي', 'فلوسي', 'ملفي', 'يومي', 'تحويل', 'الاغنياء'];
handler.desc = 'النقاط والاقتصاد 💰';
handler.descs = { 'نقاطي': 'نقاطك (∞ للمطور)', 'فلوسي': 'فلوسك', 'ملفي': 'ملفك الشخصي', 'يومي': 'مكافأتك اليومية', 'تحويل': 'حوّل نقاط للاعب', 'الاغنياء': 'أغنى 10 لاعبين' };
handler.category = 'bank';
handler.command = ['فلوسي', 'نقاطي', 'رصيدي', 'ملفي', 'بروفايل', 'يومي', 'اليومي', 'تحويل', 'حول', 'الاغنياء', 'اغنياء', 'متصدرين', 'المتصدرين'];
export default handler;
