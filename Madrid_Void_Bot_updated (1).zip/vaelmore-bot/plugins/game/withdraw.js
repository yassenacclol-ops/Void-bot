// 🏳️ انسحب - بيخرجك من أي لعبة شغالة (بنقطة أو من غير نقطة)
import { withdrawHooks } from '../../system/games_hub.js';

const run = async m => {
    for (const h of withdrawHooks) {
        const msg = await h.fn(m);
        if (msg) { await m.reply(msg); return true; }
    }
    return false;
};

const handler = async m => {
    if (!(await run(m))) return m.reply('🎮 مفيش لعبة شغالة عندك');
};

// "انسحب" من غير نقطة (زي الصورة)
handler.before = async m => {
    if (!m.text || m.isCommand || m.fromMe) return false;
    if (m.text.trim() !== 'انسحب') return false;
    return await run(m);
};

handler.usage = ['انسحب'];
handler.desc = 'الخروج من أي لعبة 🏳️';
handler.descs = { 'انسحب': 'اخرج من اللعبة الشغالة' };
handler.category = 'game';
handler.command = ['انسحب', 'انسحاب'];
export default handler;
