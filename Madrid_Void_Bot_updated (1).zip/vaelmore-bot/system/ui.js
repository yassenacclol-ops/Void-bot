// 🎨 نظام الشكل والقوائم - كل حاجة هنا بتتعدل من أوامر المطور (.قوائم)
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { getTimezone } from './timezone.js';

const FILE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'ui_config.json');

export const DEFAULTS = {
    brand: 'Madrid',                 // اسم البوت
    dev: 'Void',                     // اسم المطور
    kingdom: 'مملكة فويد',           // اسم المملكة (بيظهر في أول كل إطار)
    title: 'الأقسام',                // عنوان القايمة الرئيسية
    footer: 'إدارة',                 // كلمة التوقيع تحت الإطارات
    pick: 'اختر القسم من الزر بالأسفل',
    button: '📂 عرض الأقسام',
    headerImage: '',                 // رابط أو مسار صورة القايمة (فاضي = الكارت التلقائي)
    frame: 1,                        // شكل الإطار 1-5
    sections: {}                     // تخصيص الأقسام: { المفتاح: { name, emoji, hidden, order } }
};

let cfg;
const load = () => {
    try {
        const j = JSON.parse(fs.readFileSync(FILE, 'utf8'));
        return { ...DEFAULTS, ...j, sections: { ...(j.sections || {}) } };
    } catch { return { ...DEFAULTS, sections: {} }; }
};
cfg = load();

let t = null;
export const saveUi = () => {
    clearTimeout(t);
    t = setTimeout(() => {
        try { fs.writeFileSync(FILE + '.tmp', JSON.stringify(cfg, null, 1)); fs.renameSync(FILE + '.tmp', FILE); }
        catch (e) { console.error('[ui] مشكلة في الحفظ:', e.message); }
    }, 200);
};
export const ui = () => cfg;
export const setUi = (k, v) => { cfg[k] = v; saveUi(); };
export const resetUi = () => { cfg = { ...DEFAULTS, sections: {} }; saveUi(); };

/* ===== الإطارات (5 أشكال) ===== */
export const FRAMES = {
    1: { name: 'ملكي 🌑',  open: '┏◇━━━━━━🌑━━━━━━◇┓', close: '┗◇━━━━━━🌑━━━━━━◇┛', sep: '╾─────╼◈╾─────╼' },
    2: { name: 'نيون ✨',  open: '╔═══════ ✦ ═══════╗', close: '╚═══════ ✦ ═══════╝', sep: '╟─────────────────╢' },
    3: { name: 'صندوق 📦', open: '┌─────────────────┐', close: '└─────────────────┘', sep: '├─────────────────┤' },
    4: { name: 'ورد 🌸',   open: '❀ ━━━━━━━━━━━ ❀',   close: '❀ ━━━━━━━━━━━ ❀',   sep: '✿ ─────────── ✿' },
    5: { name: 'بسيط ➖',  open: '━━━━━━━━━━━━━━',    close: '━━━━━━━━━━━━━━',    sep: '──────────────' }
};
const frameOf = () => FRAMES[cfg.frame] || FRAMES[1];

const sig = () => `💥 ${cfg.footer} 💥\n✦ 『 ${cfg.brand} 』 ✦`;
const top = () => `🌑 ❖ إدارة ${cfg.kingdom} ❖ 🌑\n${frameOf().sep}`;

// إطار لعبة/رسالة: عنوان + سطور
export function frame(title, emoji, lines) {
    const f = frameOf();
    return [top(), `【 ${emoji} ${title} 】`, f.open, ...lines, f.close, sig()].join('\n');
}

// الوقت بتوقيت البوت (زي ما في الصورة: ٠٢:٠٧:١٤ م)
export function nowTime() {
    let tz; try { tz = getTimezone(); } catch {}
    const d = new Date();
    try { return d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: tz }); }
    catch { return d.toLocaleTimeString('ar-EG'); }
}

// نص القايمة الرئيسية (زي صورة DOMA): اسم البوت + المستخدم + الوقت + الأقسام بعدد أوامرها
export function mainMenuText({ mention, sections }) {
    const f = frameOf();
    const lines = [
        f.open,
        `⬢ ❬ ${cfg.brand.toUpperCase()} ❭ ⬢`,
        `✦ ${cfg.title} ✦`,
        f.close,
        `👤 *المستخدم* ◇ @${mention}`,
        `🕒 *الوقت* ◇ ${nowTime()}`,
        f.sep
    ];
    for (const s of sections) lines.push(`${s.emoji} *${s.name}* ◇ ${s.count} أمر${s.hidden ? ' 🙈' : ''}`);
    lines.push(f.sep, `👇 ${cfg.pick}`);
    return lines.join('\n');
}

// نص قايمة قسم واحد
export function sectionMenuText({ mention, emoji, title, rows }) {
    const f = frameOf();
    const lines = [
        `${f.open}`,
        `${emoji} *${title}*`,
        f.close,
        `👤 *المستخدم* ◇ @${mention}`,
        f.sep,
        ...rows.map(r => `${emoji} *.${r.cmd}*${r.desc ? ` ◇ ${r.desc}` : ''}`),
        f.sep,
        `👇 اختر الأمر من الزر بالأسفل`,
        '',
        sig()
    ];
    return lines.join('\n');
}

// دمج الأقسام الأصلية مع تخصيصات المطور (اسم/إيموجي/إخفاء/ترتيب)
// isVoidFlag: قسم 'void' بيظهر بس لو true - مستقل تمامًا عن isOwner العادي
export function resolveSections(CATEGORIES, liveCmds, isOwner, isVoidFlag = false) {
    const counts = {};
    for (const c of liveCmds) {
        if (!c.category) continue;
        const n = Array.isArray(c.usage) ? c.usage.filter(u => u && u !== 'undefined').length : 0;
        counts[c.category] = (counts[c.category] || 0) + n;
    }
    return CATEGORIES
        .filter(c => counts[c[2]] > 0)
        .filter(c => c[2] === 'void' ? isVoidFlag : true)
        .filter(c => (c[2] === 'owner' || c[2] === 'settings') ? isOwner : true)
        .map(c => {
            const o = cfg.sections[c[2]] || {};
            return { num: c[0], key: c[2], name: o.name || c[1], emoji: o.emoji || c[3], hidden: !!o.hidden, order: o.order ?? c[0], count: counts[c[2]] };
        })
        .filter(s => !s.hidden || isOwner)
        .sort((a, b) => a.order - b.order || a.num - b.num);
}

// اختصار الأرقام: 10000 -> 10K
export const short = n => n >= 1e6 ? `${+(n / 1e6).toFixed(1)}M` : n >= 1000 ? `${+(n / 1000).toFixed(1)}K` : String(n);
