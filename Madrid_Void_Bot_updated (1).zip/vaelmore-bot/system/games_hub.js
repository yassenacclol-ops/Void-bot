// ربط أمر انسحب بكل الألعاب: كل لعبة بتسجّل دالة هنا
// الدالة بترجع رسالة نصية لو اللاعب عنده لعبة شغالة، أو null لو مفيش
export const withdrawHooks = global.__madridWithdraw || (global.__madridWithdraw = []);
// لعبة واحدة بس شغالة في كل شات (علم / سؤال / اكس أو ...)
export const active = global.__madridActive || (global.__madridActive = new Map());

export const registerWithdraw = (id, fn) => {
    const i = withdrawHooks.findIndex(h => h.id === id);
    if (i >= 0) withdrawHooks[i] = { id, fn }; else withdrawHooks.push({ id, fn });
};
