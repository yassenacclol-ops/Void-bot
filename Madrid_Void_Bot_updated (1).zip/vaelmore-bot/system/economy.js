// 💰 نظام النقاط الموحّد: فلوس المزرعة = نقاط البوت في كل الألعاب
// المطور عنده نقاط لا نهائية (∞): مبيتخصمش منه حاجة أبدًا
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { resolveRealNumber, numOf } from './admin_utils.js';
import { GAME } from './game_config.js';
import { ui } from './ui.js';

const FILE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'farm.json');

const load = () => {
    try {
        const p = JSON.parse(fs.readFileSync(FILE, 'utf8'));
        if (p && typeof p === 'object') return p;
    } catch (e) {
        if (fs.existsSync(FILE)) { try { fs.copyFileSync(FILE, FILE + '.bak'); } catch {} }
    }
    return { users: {} };
};
if (!global.__madridEco) global.__madridEco = load();
export const DB = global.__madridEco;
if (!DB.users) DB.users = {};

let timer = null;
export const save = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
        try { fs.writeFileSync(FILE + '.tmp', JSON.stringify(DB)); fs.renameSync(FILE + '.tmp', FILE); }
        catch (e) { console.error('[economy] مشكلة في الحفظ:', e.message); }
    }, 300);
};

export const fmt = n => Number(n).toLocaleString('en-US');
export const uidOf = async (m, conn) => (await resolveRealNumber(m.sender, conn)) || numOf(m.sender);
export const uidOfJid = async (jid, conn) => (await resolveRealNumber(jid, conn)) || numOf(jid);

// بيجيب اللاعب (وبيعمله لو جديد). المطور بياخد "مملكة فويد" كاسم مزرعة تلقائي
export const getPlayer = (uid, m) => {
    let p = DB.users[uid];
    if (!p) {
        p = DB.users[uid] = { name: null, money: GAME.startMoney, seeds: {}, crops: {}, plots: [], wins: 0, createdAt: Date.now() };
    }
    if (m?.sender) p.jid = m.sender;
    if (m?.isOwner) { p.inf = true; if (!p.name) p.name = ui().kingdom; }
    save();
    return p;
};

export const isInf = (p, m) => !!(m?.isOwner || p?.inf);
export const moneyText = (p, m) => isInf(p, m) ? '∞' : fmt(p.money);

// دفع فلوس: المطور مبيدفعش (لا نهائي). بيرجع true لو العملية تمت
export const spend = (p, m, amount) => {
    if (isInf(p, m)) return true;
    if (p.money < amount) return false;
    p.money -= amount; save(); return true;
};
export const earn = (uid, amount) => {
    const p = getPlayer(uid);
    p.money += amount; save();
    return p;
};
