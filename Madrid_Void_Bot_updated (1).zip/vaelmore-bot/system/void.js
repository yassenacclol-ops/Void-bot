// system/void.js
// 🕷️ نظام Void - كل حاجة خاصة بقسم المطور الحصري (رقم واحد بس)
// الحالة بتتخزن في void_state.json عشان تعيش بعد أي ريستارت
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { numOf } from './admin_utils.js';

const FILE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'void_state.json');

// ⚠️ الرقم الوحيد اللي قسم Void بيفتحله - غيّره هنا لو حبيت تغيّر صاحب القسم
export const VOID_NUMBER = '201146255210';

const DEFAULTS = {
    frozen: {},                                    // chatId -> { until, reason, by }
    stealth: false,                                 // وضع التخفي شغال/ايقاف
    maintenance: { active: false, message: '' },    // وضع الصيانة
    event: null,                                    // { multiplier, scope, chat, game, startedAt, expiresAt }
    backup: { schedule: 'off', lastRun: 0 },        // جدولة الباكاب
    commandCount: { date: '', count: 0 }            // عداد الأوامر اليومي (لبطاقة الملك)
};

const load = () => {
    try {
        const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'));
        return { ...DEFAULTS, ...raw, maintenance: { ...DEFAULTS.maintenance, ...(raw.maintenance || {}) } };
    } catch { return { ...DEFAULTS, frozen: {} }; }
};
if (!global.__voidState) global.__voidState = load();
export const STATE = global.__voidState;

let t = null;
export const save = () => {
    clearTimeout(t);
    t = setTimeout(() => {
        try { fs.writeFileSync(FILE + '.tmp', JSON.stringify(STATE, null, 1)); fs.renameSync(FILE + '.tmp', FILE); }
        catch (e) { console.error('[void] مشكلة في الحفظ:', e.message); }
    }, 200);
};

// ===== هوية صاحب القسم =====
// ⚠️ بيفحص الرقم بس - مش قايمة owners العامة. حتى لو فيه مطورين تانيين
// مسجلين في bot.config.owners، قسم Void مبيفتحش إلا للرقم ده بالظبط.
export const isVoid = (m) => !!m?.sender && numOf(m.sender) === VOID_NUMBER;

// ===== تجميد جروب مؤقت =====
export const freezeChat = (chatId, minutes, reason, by) => {
    STATE.frozen[chatId] = {
        until: minutes > 0 ? Date.now() + minutes * 60000 : 0, // 0 = لحد ما يتفك يدوي
        reason: reason || 'بدون سبب',
        by: by || VOID_NUMBER
    };
    save();
};
export const unfreezeChat = (chatId) => { delete STATE.frozen[chatId]; save(); };
export const isFrozen = (chatId) => {
    const f = STATE.frozen[chatId];
    if (!f) return null;
    if (f.until && Date.now() > f.until) { delete STATE.frozen[chatId]; save(); return null; }
    return f;
};

// ===== وضع الصيانة =====
export const setMaintenance = (active, message) => {
    STATE.maintenance = { active: !!active, message: message || STATE.maintenance.message || 'البوت تحت الصيانة دلوقتي، ارجع بعد شوية 🔧' };
    save();
};
export const getMaintenance = () => STATE.maintenance;

// ===== وضع التخفي =====
export const setStealth = (on) => { STATE.stealth = !!on; save(); };
export const getStealth = () => !!STATE.stealth;

// ===== حدث مضاعفة النقاط =====
export const startEvent = ({ multiplier, minutes, scope, chat, game }) => {
    const mult = Math.max(1, Math.min(10, Number(multiplier) || 2));
    STATE.event = {
        multiplier: mult,
        scope: scope === 'chat' ? 'chat' : 'global',   // 'global' = كل الجروبات، 'chat' = جروب واحد بس
        chat: scope === 'chat' ? chat : null,
        game: game || null,                             // null = كل الألعاب، أو اسم لعبة محدد
        startedAt: Date.now(),
        expiresAt: minutes > 0 ? Date.now() + minutes * 60000 : 0
    };
    save();
    return STATE.event;
};
export const stopEvent = () => { STATE.event = null; save(); };
export const getEvent = () => {
    const e = STATE.event;
    if (!e) return null;
    if (e.expiresAt && Date.now() > e.expiresAt) { STATE.event = null; save(); return null; }
    return e;
};
// بيتطبق في أي مكان فلوس بتتدفع فيه للاعب - بيرجع المبلغ بعد الضرب (أو زي ما هو لو مفيش حدث شغال)
export const applyMultiplier = (amount, { chatId, game } = {}) => {
    const e = getEvent();
    if (!e) return amount;
    if (e.scope === 'chat' && e.chat !== chatId) return amount;
    if (e.game && game && e.game !== game) return amount;
    return Math.round(amount * e.multiplier);
};

// ===== جدولة الباكاب =====
export const setBackupSchedule = (schedule) => { STATE.backup.schedule = schedule; save(); };
export const getBackupSchedule = () => STATE.backup.schedule;
export const markBackupRun = () => { STATE.backup.lastRun = Date.now(); save(); };

// ===== سناب شوت تلقائي قبل أي أمر خطير (eval/exec/تحديث) =====
// محدود بفاصل أدنى عشان ميعملش نسخة في كل ثانية وقت تجربة كود سريع
let _lastRiskySnap = 0;
const RISKY_THROTTLE_MS = 5 * 60 * 1000;
export const maybeRiskySnapshot = (label) => {
    const now = Date.now();
    if (now - _lastRiskySnap < RISKY_THROTTLE_MS) return;
    _lastRiskySnap = now;
    import('../plugins/void/backup.js')
        .then(({ createVoidBackup }) => createVoidBackup(label || 'قبل_خطر'))
        .catch((e) => console.error('[void] فشل سناب شوت قبل أمر خطير:', e.message));
};

// ===== رد موحّد لأوامر Void - بيحترم وضع التخفي تلقائيًا =====
// لو التخفي شغال: بيمسح رسالة الأمر الأصلية (لو البوت يقدر) ويبعت الرد في
// الخاص لصاحب Void بدل الجروب. لو التخفي مقفول: بيرد عادي في نفس الشات.
export const voidReply = async (m, conn, text) => {
    if (!getStealth()) return m.reply(text);
    try { await m.delete?.(); } catch {}
    try {
        const dm = `${VOID_NUMBER}@s.whatsapp.net`;
        await conn.sendMessage(dm, { text: `🕶️ *رد من Void (${m.chat.endsWith('@g.us') ? 'جروب' : 'شات'}):*\n${text}` });
    } catch (e) { console.error('[void] فشل إرسال رد التخفي:', e.message); }
};

// ===== زي voidReply بس لصورة - بيستخدمها .الملك ونظام التجميد لو عايز يبعت صورة =====
export const voidReplyImage = async (m, conn, imgBuffer, caption) => {
    if (!getStealth()) return conn.sendMessage(m.chat, { image: imgBuffer, caption }, { quoted: m });
    try { await m.delete?.(); } catch {}
    try {
        const dm = `${VOID_NUMBER}@s.whatsapp.net`;
        await conn.sendMessage(dm, { image: imgBuffer, caption: `🕶️ ${caption || ''}` });
    } catch (e) { console.error('[void] فشل إرسال صورة التخفي:', e.message); }
};

// ===== عداد الأوامر اليومي (لبطاقة الملك) =====
const today = () => new Date().toISOString().slice(0, 10);
export const bumpCommandCount = () => {
    if (STATE.commandCount.date !== today()) STATE.commandCount = { date: today(), count: 0 };
    STATE.commandCount.count++;
    save();
};
export const getCommandCount = () => (STATE.commandCount.date === today() ? STATE.commandCount.count : 0);
