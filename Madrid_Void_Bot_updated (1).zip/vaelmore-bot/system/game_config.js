// ⚙️ إعدادات الألعاب والاقتصاد - عدّل الأرقام هنا براحتك
export const GAME = {
    startMoney: 100,                 // الفلوس (النقاط) اللي بيبدأ بيها أي لاعب
    daily: { base: 1000, streakBonus: 250, maxStreak: 7 },
    transfer: { min: 10, feePercent: 5 },
    farm: { spoilChance: 0.25, maxPlants: 50 },
    flag: { timeSec: 30, hintExtraSec: 20, rewardFull: 10000, rewardHint: 5000 },
    quiz: { timeSec: 25, reward: 2000 },
    scramble: { timeSec: 25, reward: 1500 },
    capitals: { timeSec: 25, reward: 1500 },
    xo: { reward: 3000, moveSec: 90 }
};
